<?php
header('Content-Type: application/json');

class MessageApi
{
    private $dataFile;

    public function __construct()
    {
        $this->dataFile = __DIR__ . '/../data/message.json';

        if (!file_exists($this->dataFile)) {
            file_put_contents($this->dataFile, json_encode(JSON_PRETTY_PRINT));
        }
    }

    public function handleRequest()
    {
        if ($_SERVER['REQUEST_METHOD'] === 'GET') {
            $this->handleGet();
        }
    }

    private function handleGet()
    {
        $data = json_decode(file_get_contents($this->dataFile), true);
        echo json_encode($data);
    }
}

$api = new MessageApi();
$api->handleRequest();
