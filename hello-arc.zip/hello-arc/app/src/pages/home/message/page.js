// app/src/pages/messages/page.js
$(document).ready(function () {
    loadMessage();
});

function createMessageBubble(message) {
    return $('<div>', {
        class: 'transition-all duration-300 opacity-0 transform translate-y-2'
    }).append(
        // Time stamp
        $('<div>', {
            class: 'text-xs text-gray-500 mb-1',
            text: new Date().toLocaleTimeString()
        }),
        // Message container
        $('<div>', {
            class: 'bg-green-900 p-4 rounded-lg shadow-lg max-w-md ' +
                'border border-green-700 font-mono text-green-300'
        }).append(
            // Message with cursor
            $('<div>', {
                class: 'flex items-center gap-2'
            }).append(
                $('<span>', { text: message }),
                // Cursor (opacity animation handled by setInterval)
                $('<span>', {
                    class: 'h-4 w-2 bg-green-400',
                    id: 'cursor'
                })
            )
        )
    ).fadeIn(300); // jQuery's fadeIn for animation
}

function createRetroTerminal() {
    return $('<div>', {
        class: 'bg-black/90 p-8 rounded-xl border-2 border-green-800 shadow-2xl'
    }).append(
        // Terminal header
        $('<div>', {
            class: 'mb-4 flex items-center gap-2'
        }).append(
            $('<div>', {
                class: 'w-3 h-3 rounded-full bg-red-500'
            }),
            $('<div>', {
                class: 'w-3 h-3 rounded-full bg-yellow-500'
            }),
            $('<div>', {
                class: 'w-3 h-3 rounded-full bg-green-500'
            })
        ),
        // Messages container
        $('<div>', {
            id: 'messages',
            class: 'space-y-4 min-h-[200px]'
        })
    );
}

function loadMessage() {
    // First time setup
    if (!$('.terminal-container').length) {
        $('#message').empty().append(createRetroTerminal());
    }

    $.ajax({
        url: '/src/apis/message.php',
        method: 'GET',
        success: function (data) {
            const $messagesBubble = createMessageBubble(data.message);
            $('#messages').append($messagesBubble);

            // Blink cursor using setInterval
            setInterval(function () {
                $('#cursor').toggleClass('opacity-0');
            }, 500);
        },
    });
}