<div id="message" class="flex items-center justify-center min-h-screen bg-gray-900 p-4">
    <!-- Terminal will be inserted here -->
</div>

<script src="/src/pages/home/message/page.js"></script>