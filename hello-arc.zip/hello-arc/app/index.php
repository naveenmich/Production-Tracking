<?php
require_once 'src/pages/layout.php';

$path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$path = rtrim($path, '/');

if (strpos($path, '/src/apis/') === 0) {
    $apiFile = __DIR__ . $path;
    if (file_exists($apiFile)) {
        require_once $apiFile;
        exit;
    }
}

if ($path == '') {
    $path = '/home/message';
}

ob_start();

switch ($path) {
    case '/home/message':
        require_once 'src/pages/home/message/page.php';
        break;

    default:
        http_response_code(404);
        echo "404 - Page not found";
        break;
}

$content = ob_get_clean();
renderLayout($content);
