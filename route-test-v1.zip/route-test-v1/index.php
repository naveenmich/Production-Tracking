<?php

/**
 * Main entry point for the website
 * Clean routes using page names
 */

// Include the Router class
require_once 'Router.php';

// Create router instance
$router = new Router();

// Define page routes (both GET and POST handled automatically)
$router->page('/', 'home');
$router->page('/about', 'about');
$router->page('/contact', 'contact');

// Set 404 page
$router->notFound('not-found');

// Run the router
$router->run();
