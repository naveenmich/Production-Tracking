<!-- views/partials/footer.php -->
</main>

<footer>
    <p>&copy; <?= date('Y') ?> My PHP Website</p>
</footer>
</body>

</html>