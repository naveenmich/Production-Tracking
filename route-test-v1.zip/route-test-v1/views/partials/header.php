<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= Scaffold::escape($this->getTitle()) ?></title>

    <!-- CSS -->
    <link rel="stylesheet" href="/assets/css/style.css">

    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>

</head>

<body>
    <header>
        <nav>
            <ul>
                <li><a href="/" <?= $currentPath === '/' ? 'class="active"' : '' ?>>Home</a></li>
                <li><a href="/about" <?= $currentPath === '/about' ? 'class="active"' : '' ?>>About</a></li>
                <li><a href="/contact" <?= $currentPath === '/contact' ? 'class="active"' : '' ?>>Contact</a></li>
            </ul>
        </nav>
    </header>

    <main>