<?php

/**
 * views/pages/home/page.php
 * 
 * Home page display file
 * Uses data and functions from actions.php
 */

// Set the page title
Scaffold::getInstance()->setTitle($pageTitle);

// Get data from functions
$featuredProducts = getFeaturedProducts();
$latestPosts = getLatestPosts();
$testimonials = getTestimonials();
$stats = getStats();

// Get any success/error messages for forms
$subscribeSuccess = $_SESSION['subscribe_success'] ?? null;
$subscribeError = $_SESSION['subscribe_error'] ?? null;

// Clear session messages
if (isset($_SESSION['subscribe_success'])) unset($_SESSION['subscribe_success']);
if (isset($_SESSION['subscribe_error'])) unset($_SESSION['subscribe_error']);
?>

<!-- Hero Section -->
<section class="hero">
    <div class="hero-content">
        <h1><?= Scaffold::escape($heroTagline) ?></h1>
        <p class="hero-description"><?= Scaffold::escape($heroDescription) ?></p>
        <div class="hero-buttons">
            <a href="/about" class="button">Learn More</a>
            <a href="/contact" class="button button-outline">Contact Us</a>
        </div>
    </div>
</section>

<!-- Stats Section -->
<section class="stats-section">
    <div class="stats-container">
        <?php foreach ($stats as $stat): ?>
            <div class="stat-item">
                <div class="stat-value"><?= Scaffold::escape($stat['value']) ?></div>
                <div class="stat-label"><?= Scaffold::escape($stat['label']) ?></div>
            </div>
        <?php endforeach; ?>
    </div>
</section>

<!-- Featured Products Section -->
<section class="content-section">
    <h2 class="section-title">Our Solutions</h2>
    <div class="products-container">
        <?php foreach ($featuredProducts as $product): ?>
            <div class="product-card">
                <h3><?= Scaffold::escape($product['name']) ?></h3>
                <div class="product-price">$<?= number_format($product['price'], 2) ?></div>
                <p class="product-description"><?= Scaffold::escape($product['description']) ?></p>
                <a href="/products/<?= $product['id'] ?>" class="button">Learn More</a>
            </div>
        <?php endforeach; ?>
    </div>
</section>

<!-- Blog Posts Section -->
<section class="content-section light-bg">
    <h2 class="section-title">Latest News</h2>
    <div class="posts-container">
        <?php foreach ($latestPosts as $post): ?>
            <div class="post-card">
                <h3><?= Scaffold::escape($post['title']) ?></h3>
                <div class="post-meta">
                    <span class="post-date"><?= date('F j, Y', strtotime($post['date'])) ?></span>
                    <span class="post-author">by <?= Scaffold::escape($post['author']) ?></span>
                </div>
                <p class="post-excerpt"><?= Scaffold::escape($post['excerpt']) ?></p>
                <a href="/blog/<?= $post['id'] ?>" class="read-more">Read More →</a>
            </div>
        <?php endforeach; ?>
    </div>
</section>

<!-- Testimonials Section -->
<section class="content-section">
    <h2 class="section-title">What Our Clients Say</h2>
    <div class="testimonials-container">
        <?php foreach ($testimonials as $testimonial): ?>
            <div class="testimonial-card">
                <div class="testimonial-rating">
                    <?php for ($i = 1; $i <= 5; $i++): ?>
                        <span class="star<?= $i <= $testimonial['rating'] ? ' filled' : '' ?>">★</span>
                    <?php endfor; ?>
                </div>
                <blockquote><?= Scaffold::escape($testimonial['text']) ?></blockquote>
                <div class="testimonial-author">
                    <strong><?= Scaffold::escape($testimonial['name']) ?></strong>
                    <span><?= Scaffold::escape($testimonial['company']) ?></span>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</section>

<!-- Newsletter Section -->
<section class="newsletter-section">
    <div class="newsletter-content">
        <h2>Stay Updated</h2>
        <p>Subscribe to our newsletter to receive the latest updates and news.</p>

        <?php if ($subscribeSuccess): ?>
            <div class="alert success">
                <p><?= Scaffold::escape($subscribeSuccess) ?></p>
            </div>
        <?php else: ?>
            <?php if ($subscribeError): ?>
                <div class="alert error">
                    <p><?= Scaffold::escape($subscribeError) ?></p>
                </div>
            <?php endif; ?>

            <form method="post" action="/" class="newsletter-form">
                <input type="hidden" name="form_action" value="quick_subscribe">
                <div class="form-group">
                    <input type="email" name="email" placeholder="Your email address" required>
                    <button type="submit" class="button">Subscribe</button>
                </div>
            </form>
        <?php endif; ?>
    </div>
</section>

<style>
    /* Additional styles for the home page */
    .hero {
        background-color: #2c3e50;
        color: white;
        padding: 4rem 2rem;
        text-align: center;
    }

    .hero-content {
        max-width: 800px;
        margin: 0 auto;
    }

    .hero h1 {
        font-size: 2.5rem;
        margin-bottom: 1rem;
    }

    .hero-description {
        font-size: 1.2rem;
        margin-bottom: 2rem;
        opacity: 0.9;
    }

    .hero-buttons {
        display: flex;
        justify-content: center;
        gap: 1rem;
    }

    .button {
        display: inline-block;
        background-color: #3498db;
        color: white;
        padding: 0.75rem 1.5rem;
        border-radius: 4px;
        text-decoration: none;
        font-weight: bold;
        transition: background-color 0.3s;
    }

    .button:hover {
        background-color: #2980b9;
    }

    .button-outline {
        background-color: transparent;
        border: 2px solid white;
    }

    .button-outline:hover {
        background-color: rgba(255, 255, 255, 0.1);
    }

    /* Stats section */
    .stats-section {
        background-color: #f8f9fa;
        padding: 2rem;
    }

    .stats-container {
        display: flex;
        justify-content: space-around;
        max-width: 1200px;
        margin: 0 auto;
        flex-wrap: wrap;
    }

    .stat-item {
        text-align: center;
        padding: 1rem;
    }

    .stat-value {
        font-size: 2.5rem;
        font-weight: bold;
        color: #3498db;
    }

    .stat-label {
        font-size: 1.1rem;
        color: #555;
    }

    /* Content sections */
    .content-section {
        padding: 4rem 2rem;
    }

    .light-bg {
        background-color: #f8f9fa;
    }

    .section-title {
        text-align: center;
        margin-bottom: 2rem;
        color: #2c3e50;
    }

    /* Products */
    .products-container {
        display: flex;
        justify-content: center;
        gap: 2rem;
        flex-wrap: wrap;
        max-width: 1200px;
        margin: 0 auto;
    }

    .product-card {
        background-color: white;
        border-radius: 8px;
        box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        padding: 2rem;
        width: 300px;
        text-align: center;
    }

    .product-price {
        font-size: 1.5rem;
        font-weight: bold;
        color: #3498db;
        margin: 1rem 0;
    }

    .product-description {
        color: #666;
        margin-bottom: 1.5rem;
    }

    /* Blog posts */
    .posts-container {
        display: flex;
        justify-content: center;
        gap: 2rem;
        flex-wrap: wrap;
        max-width: 1200px;
        margin: 0 auto;
    }

    .post-card {
        background-color: white;
        border-radius: 8px;
        box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        padding: 2rem;
        width: 300px;
    }

    .post-meta {
        color: #666;
        font-size: 0.9rem;
        margin-bottom: 1rem;
    }

    .post-excerpt {
        color: #444;
        margin-bottom: 1rem;
    }

    .read-more {
        color: #3498db;
        text-decoration: none;
        font-weight: bold;
    }

    /* Testimonials */
    .testimonials-container {
        display: flex;
        justify-content: center;
        gap: 2rem;
        flex-wrap: wrap;
        max-width: 1200px;
        margin: 0 auto;
    }

    .testimonial-card {
        background-color: #f8f9fa;
        border-radius: 8px;
        padding: 2rem;
        width: 300px;
    }

    .testimonial-rating {
        margin-bottom: 1rem;
    }

    .star {
        color: #ddd;
        font-size: 1.2rem;
    }

    .star.filled {
        color: #f1c40f;
    }

    blockquote {
        font-style: italic;
        color: #555;
        margin: 0 0 1rem 0;
    }

    .testimonial-author {
        text-align: right;
    }

    /* Newsletter section */
    .newsletter-section {
        background-color: #3498db;
        color: white;
        padding: 4rem 2rem;
        text-align: center;
    }

    .newsletter-content {
        max-width: 600px;
        margin: 0 auto;
    }

    .newsletter-form {
        margin-top: 2rem;
    }

    .newsletter-form .form-group {
        display: flex;
    }

    .newsletter-form input {
        flex: 1;
        padding: 0.75rem;
        border: none;
        border-radius: 4px 0 0 4px;
    }

    .newsletter-form button {
        border-radius: 0 4px 4px 0;
    }

    .alert {
        padding: 1rem;
        border-radius: 4px;
        margin: 1rem 0;
    }

    .success {
        background-color: rgba(46, 204, 113, 0.2);
        color: #27ae60;
    }

    .error {
        background-color: rgba(231, 76, 60, 0.2);
        color: #e74c3c;
    }

    /* Responsive adjustments */
    @media (max-width: 768px) {
        .hero h1 {
            font-size: 2rem;
        }

        .product-card,
        .post-card,
        .testimonial-card {
            width: 100%;
        }

        .newsletter-form .form-group {
            flex-direction: column;
        }

        .newsletter-form input {
            border-radius: 4px;
            margin-bottom: 0.5rem;
        }

        .newsletter-form button {
            border-radius: 4px;
            width: 100%;
        }
    }
</style>