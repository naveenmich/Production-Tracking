<?php

/**
 * views/pages/home/actions.php
 * 
 * Contains data and functions for the home page
 */

// Page data
$pageTitle = 'Welcome to Our Website';
$heroTagline = 'Building Better Solutions';
$heroDescription = 'We create innovative products and services to help businesses grow.';

/**
 * Get featured products
 * In a real app, this would come from a database
 */
function getFeaturedProducts() {
    return [
        [
            'id' => 1,
            'name' => 'Premium Package',
            'price' => 99.99,
            'description' => 'Our most popular option with all features included.',
            'featured' => true
        ],
        [
            'id' => 2,
            'name' => 'Standard Package',
            'price' => 49.99,
            'description' => 'Perfect for small businesses and startups.',
            'featured' => true
        ],
        [
            'id' => 3,
            'name' => 'Basic Package',
            'price' => 19.99,
            'description' => 'Essential features to get you started.',
            'featured' => true
        ]
    ];
}

/**
 * Get latest blog posts
 * In a real app, this would come from a database
 */
function getLatestPosts() {
    return [
        [
            'id' => 1,
            'title' => 'Introducing Our New Platform',
            'date' => '2025-03-01',
            'excerpt' => 'We\'re excited to announce the launch of our new platform with enhanced features.',
            'author' => 'John Smith'
        ],
        [
            'id' => 2,
            'title' => 'Tips for Growing Your Business',
            'date' => '2025-02-15',
            'excerpt' => 'Learn the top strategies that helped our clients increase revenue by 30%.',
            'author' => 'Jane Doe'
        ],
        [
            'id' => 3,
            'title' => 'Customer Success Story: XYZ Corp',
            'date' => '2025-02-01',
            'excerpt' => 'How XYZ Corp transformed their operations and doubled productivity.',
            'author' => 'Mike Johnson'
        ]
    ];
}

/**
 * Get testimonials
 */
function getTestimonials() {
    return [
        [
            'name' => 'Sarah Thompson',
            'company' => 'Acme Inc.',
            'text' => 'This product has completely transformed how we operate. Our efficiency has improved by 45%.',
            'rating' => 5
        ],
        [
            'name' => 'Robert Chen',
            'company' => 'Tech Solutions',
            'text' => 'The customer support is outstanding. Any issue we had was resolved within hours.',
            'rating' => 5
        ],
        [
            'name' => 'Lisa Rodriguez',
            'company' => 'Growth Partners',
            'text' => 'We\'ve tried many similar services, but this one stands out for its reliability and features.',
            'rating' => 4
        ]
    ];
}

/**
 * Get featured stats to display
 */
function getStats() {
    return [
        [
            'value' => '500+',
            'label' => 'Clients'
        ],
        [
            'value' => '15+',
            'label' => 'Years Experience'
        ],
        [
            'value' => '98%',
            'label' => 'Satisfaction Rate'
        ],
        [
            'value' => '24/7',
            'label' => 'Support'
        ]
    ];
}

/**
 * Process any form submissions on the home page
 * For example, a "Subscribe to updates" form
 */
function processForm() {
    $formAction = $_POST['form_action'] ?? '';

    if ($formAction === 'quick_subscribe') {
        $email = $_POST['email'] ?? '';

        // Validate email
        if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $_SESSION['subscribe_error'] = 'Please enter a valid email address.';
            return;
        }

        // In a real app, you would save this to a database
        // ...

        $_SESSION['subscribe_success'] = 'Thank you for subscribing!';
    }
}
