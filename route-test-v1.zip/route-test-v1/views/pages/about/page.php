<?php

/**
 * views/pages/about/page.php
 * 
 * About page display file
 * Uses data and functions from actions.php
 */

// Set the page title
Scaffold::getInstance()->setTitle($pageTitle);

// Get data from functions
$milestones = getMilestones();
$teamMembers = getTeamMembers();
$companyValues = getCompanyValues();
?>

<!-- Hero Section -->
<section class="hero about-hero">
    <div class="hero-content">
        <h1>About <?= Scaffold::escape($companyName) ?></h1>
        <p class="hero-description"><?= Scaffold::escape($companyDescription) ?></p>
    </div>
</section>

<!-- Company Values Section -->
<section class="content-section">
    <h2 class="section-title">Our Values</h2>
    <div class="values-container">
        <?php foreach ($companyValues as $value): ?>
            <div class="value-card">
                <h3><?= Scaffold::escape($value['title']) ?></h3>
                <p><?= Scaffold::escape($value['description']) ?></p>
            </div>
        <?php endforeach; ?>
    </div>
</section>

<!-- Timeline Section -->
<section class="content-section light-bg">
    <h2 class="section-title">Our Journey</h2>
    <div class="timeline">
        <?php foreach ($milestones as $index => $milestone): ?>
            <div class="timeline-item <?= $index % 2 === 0 ? 'left' : 'right' ?>">
                <div class="timeline-content">
                    <div class="year"><?= Scaffold::escape($milestone['year']) ?></div>
                    <h3><?= Scaffold::escape($milestone['title']) ?></h3>
                    <p><?= Scaffold::escape($milestone['description']) ?></p>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</section>

<!-- Team Section -->
<section class="content-section">
    <h2 class="section-title">Our Leadership Team</h2>
    <div class="team-container">
        <?php foreach ($teamMembers as $member): ?>
            <div class="team-member">
                <div class="member-image">
                    <!-- Using a placeholder for the demo -->
                    <div class="placeholder-image"><?= substr($member['name'], 0, 1) ?></div>
                </div>
                <h3><?= Scaffold::escape($member['name']) ?></h3>
                <div class="member-position"><?= Scaffold::escape($member['position']) ?></div>
                <p class="member-bio"><?= Scaffold::escape($member['bio']) ?></p>
            </div>
        <?php endforeach; ?>
    </div>
</section>

<!-- Call to Action -->
<section class="cta-section">
    <div class="cta-content">
        <h2>Ready to Work With Us?</h2>
        <p>Let's discuss how we can help your business grow.</p>
        <a href="/contact" class="button">Contact Us</a>
    </div>
</section>

<style>
    /* Additional styles for the about page */

    .about-hero {
        background-color: #2c3e50;
        color: white;
        padding: 4rem 2rem;
        text-align: center;
    }

    .about-hero .hero-content {
        max-width: 800px;
        margin: 0 auto;
    }

    /* Company values */
    .values-container {
        display: flex;
        flex-wrap: wrap;
        justify-content: center;
        gap: 2rem;
        max-width: 1200px;
        margin: 0 auto;
    }

    .value-card {
        background-color: #f8f9fa;
        border-radius: 8px;
        padding: 2rem;
        width: 250px;
        text-align: center;
        box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
    }

    .value-card h3 {
        color: #3498db;
        margin-bottom: 1rem;
    }

    /* Timeline */
    .timeline {
        position: relative;
        max-width: 1200px;
        margin: 0 auto;
        padding: 2rem 0;
    }

    .timeline::after {
        content: '';
        position: absolute;
        width: 6px;
        background-color: #ddd;
        top: 0;
        bottom: 0;
        left: 50%;
        margin-left: -3px;
    }

    .timeline-item {
        padding: 10px 40px;
        position: relative;
        width: 50%;
        box-sizing: border-box;
    }

    .timeline-item.left {
        left: 0;
    }

    .timeline-item.right {
        left: 50%;
    }

    .timeline-content {
        padding: 20px;
        background-color: white;
        border-radius: 8px;
        box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        position: relative;
    }

    .timeline-content::after {
        content: '';
        position: absolute;
        width: 20px;
        height: 20px;
        background-color: white;
        border: 4px solid #3498db;
        border-radius: 50%;
        top: 20px;
        z-index: 1;
    }

    .timeline-item.left .timeline-content::after {
        right: -50px;
    }

    .timeline-item.right .timeline-content::after {
        left: -50px;
    }

    .year {
        display: inline-block;
        background-color: #3498db;
        color: white;
        padding: 0.25rem 0.75rem;
        border-radius: 4px;
        margin-bottom: 0.5rem;
        font-weight: bold;
    }

    /* Team members */
    .team-container {
        display: flex;
        flex-wrap: wrap;
        justify-content: center;
        gap: 2rem;
        max-width: 1200px;
        margin: 0 auto;
    }

    .team-member {
        background-color: white;
        border-radius: 8px;
        padding: 2rem;
        width: 250px;
        text-align: center;
        box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
    }

    .member-image {
        margin-bottom: 1rem;
    }

    .placeholder-image {
        width: 100px;
        height: 100px;
        background-color: #3498db;
        color: white;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 2.5rem;
        margin: 0 auto;
    }

    .member-position {
        color: #666;
        font-style: italic;
        margin-bottom: 1rem;
    }

    .member-bio {
        color: #444;
        font-size: 0.9rem;
    }

    /* Call to action */
    .cta-section {
        background-color: #3498db;
        color: white;
        padding: 4rem 2rem;
        text-align: center;
    }

    .cta-content {
        max-width: 600px;
        margin: 0 auto;
    }

    .cta-content .button {
        background-color: white;
        color: #3498db;
        margin-top: 1.5rem;
    }

    .cta-content .button:hover {
        background-color: #f8f9fa;
    }

    /* Responsive adjustments */
    @media (max-width: 768px) {
        .timeline::after {
            left: 31px;
        }

        .timeline-item {
            width: 100%;
            padding-left: 70px;
            padding-right: 25px;
        }

        .timeline-item.right {
            left: 0;
        }

        .timeline-item.left .timeline-content::after,
        .timeline-item.right .timeline-content::after {
            left: -36px;
        }

        .value-card,
        .team-member {
            width: 100%;
        }
    }
</style>