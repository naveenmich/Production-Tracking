<?php

/**
 * views/pages/about/actions.php
 * 
 * Contains data and functions for the about page
 */

// Page data
$pageTitle = 'About Us';
$companyName = 'Your Company Name';
$companyDescription = 'We are a passionate team dedicated to creating innovative solutions that help businesses succeed in the digital age. Founded in 2010, we have been serving clients worldwide with a commitment to excellence and customer satisfaction.';

/**
 * Get company history milestones
 */
function getMilestones() {
    return [
        [
            'year' => '2010',
            'title' => 'Company Founded',
            'description' => 'Our journey began with a small team of 3 developers working from a garage.'
        ],
        [
            'year' => '2013',
            'title' => 'First Major Client',
            'description' => 'Secured our first enterprise client and expanded to a team of 15.'
        ],
        [
            'year' => '2016',
            'title' => 'International Expansion',
            'description' => 'Opened our first international office in London.'
        ],
        [
            'year' => '2019',
            'title' => 'Product Launch',
            'description' => 'Launched our flagship product that now serves over 500 businesses.'
        ],
        [
            'year' => '2022',
            'title' => 'Major Acquisition',
            'description' => 'Acquired a leading tech startup to enhance our service offerings.'
        ],
        [
            'year' => '2025',
            'title' => 'Where We Are Today',
            'description' => 'Now a team of 150+ professionals serving clients in over 30 countries.'
        ],
    ];
}

/**
 * Get team members
 */
function getTeamMembers() {
    return [
        [
            'name' => 'John Smith',
            'position' => 'CEO & Founder',
            'bio' => 'John has over 20 years of experience in the tech industry and founded the company in 2010.',
            'image' => 'john.jpg'
        ],
        [
            'name' => 'Jane Doe',
            'position' => 'CTO',
            'bio' => 'With a Ph.D. in Computer Science, Jane leads our technical team and drives innovation.',
            'image' => 'jane.jpg'
        ],
        [
            'name' => 'Mike Johnson',
            'position' => 'CFO',
            'bio' => 'Mike brings 15 years of financial expertise and has been with us since 2012.',
            'image' => 'mike.jpg'
        ],
        [
            'name' => 'Sarah Williams',
            'position' => 'COO',
            'bio' => 'Sarah ensures our operations run smoothly and efficiently across all departments.',
            'image' => 'sarah.jpg'
        ],
    ];
}

/**
 * Get company values
 */
function getCompanyValues() {
    return [
        [
            'title' => 'Innovation',
            'description' => 'We constantly push boundaries and explore new technologies to deliver cutting-edge solutions.'
        ],
        [
            'title' => 'Quality',
            'description' => 'We are committed to delivering high-quality products and services that exceed expectations.'
        ],
        [
            'title' => 'Integrity',
            'description' => 'We operate with honesty, transparency, and ethical standards in all our dealings.'
        ],
        [
            'title' => 'Customer Focus',
            'description' => "Our clients' success is our success. We prioritize their needs and satisfaction."
        ],
    ];
}
