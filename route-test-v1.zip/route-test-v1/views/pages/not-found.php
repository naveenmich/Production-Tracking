<section class="hero error-page">
    <h1>404</h1>
    <p>Page Not Found</p>
    <a href="/" class="button">Go to Home Page</a>
</section>