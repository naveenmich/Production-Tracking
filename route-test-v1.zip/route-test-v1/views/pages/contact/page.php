<?php

/**
 * views/pages/contact/page.php
 * 
 * Displays the contact form
 * Variables and functions from actions.php are available here
 */

// Set the page title from the actions.php file
Scaffold::getInstance()->setTitle($pageTitle);
?>
<section class="hero">
    <h1>Contact Us</h1>
</section>

<section class="content">
    <div class="contact-container">
        <!-- Contact Form Section -->
        <div class="contact-form-section">
            <h2>Send Us a Message</h2>

            <?php if ($successMessage): ?>
                <div class="alert success">
                    <p><?= Scaffold::escape($successMessage) ?></p>
                    <p><a href="/contact" class="button">Send another message</a></p>
                </div>
            <?php else: ?>
                <p>We'd love to hear from you! Fill out the form below.</p>

                <form id="contact-form" method="post" action="/contact">
                    <!-- Hidden field to identify which form is being submitted -->
                    <input type="hidden" name="form_action" value="contact_message">

                    <div class="form-group <?= isset($errors['name']) ? 'has-error' : '' ?>">
                        <label for="name">Name:</label>
                        <input type="text" id="name" name="name" value="<?= Scaffold::escape($formData['name']) ?>">
                        <?php if (isset($errors['name'])): ?>
                            <div class="error-message"><?= Scaffold::escape($errors['name']) ?></div>
                        <?php endif; ?>
                    </div>

                    <div class="form-group <?= isset($errors['email']) ? 'has-error' : '' ?>">
                        <label for="email">Email:</label>
                        <input type="email" id="email" name="email" value="<?= Scaffold::escape($formData['email']) ?>">
                        <?php if (isset($errors['email'])): ?>
                            <div class="error-message"><?= Scaffold::escape($errors['email']) ?></div>
                        <?php endif; ?>
                    </div>

                    <div class="form-group <?= isset($errors['message']) ? 'has-error' : '' ?>">
                        <label for="message">Message:</label>
                        <textarea id="message" name="message" rows="5"><?= Scaffold::escape($formData['message']) ?></textarea>
                        <?php if (isset($errors['message'])): ?>
                            <div class="error-message"><?= Scaffold::escape($errors['message']) ?></div>
                        <?php endif; ?>
                    </div>

                    <button type="submit" class="button">Send Message</button>
                </form>
            <?php endif; ?>
        </div>

        <!-- Newsletter Section -->
        <div class="newsletter-section">
            <h2>Subscribe to Our Newsletter</h2>

            <?php if ($newsletterSuccessMessage): ?>
                <div class="alert success">
                    <p><?= Scaffold::escape($newsletterSuccessMessage) ?></p>
                </div>
            <?php else: ?>
                <p>Stay updated with our latest news and offers.</p>

                <form id="newsletter-form" method="post" action="/contact">
                    <!-- Hidden field to identify which form is being submitted -->
                    <input type="hidden" name="form_action" value="newsletter_signup">

                    <div class="form-group <?= isset($errors['newsletter_email']) ? 'has-error' : '' ?>">
                        <label for="newsletter_email">Email:</label>
                        <input type="email" id="newsletter_email" name="newsletter_email" value="<?= Scaffold::escape($newsletterEmail) ?>">
                        <?php if (isset($errors['newsletter_email'])): ?>
                            <div class="error-message"><?= Scaffold::escape($errors['newsletter_email']) ?></div>
                        <?php endif; ?>
                    </div>

                    <button type="submit" class="button">Subscribe</button>
                </form>
            <?php endif; ?>
        </div>
    </div>
</section>

<style>
    .contact-container {
        display: flex;
        flex-wrap: wrap;
        gap: 2rem;
    }

    .contact-form-section {
        flex: 2;
        min-width: 300px;
    }

    .newsletter-section {
        flex: 1;
        min-width: 250px;
        background-color: #f5f5f5;
        padding: 1.5rem;
        border-radius: 4px;
    }
</style>

<script>
    $(document).ready(function() {
        // Client-side validation if needed
    });
</script>