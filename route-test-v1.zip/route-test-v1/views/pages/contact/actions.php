<?php

/**
 * views/pages/contact/actions.php
 * 
 * Contains data and functions for the contact page
 */

// Page data
$pageTitle = 'Contact Us';

// Get form data and errors from session if they exist
$formData = $_SESSION['form_data'] ?? [
    'name' => '',
    'email' => '',
    'message' => ''
];

$newsletterEmail = $_SESSION['newsletter_email'] ?? '';

$errors = $_SESSION['errors'] ?? [];
$successMessage = $_SESSION['success_message'] ?? null;
$newsletterSuccessMessage = $_SESSION['newsletter_success'] ?? null;

// Clear session variables after retrieving them
if (isset($_SESSION['form_data'])) unset($_SESSION['form_data']);
if (isset($_SESSION['newsletter_email'])) unset($_SESSION['newsletter_email']);
if (isset($_SESSION['errors'])) unset($_SESSION['errors']);
if (isset($_SESSION['success_message'])) unset($_SESSION['success_message']);
if (isset($_SESSION['newsletter_success'])) unset($_SESSION['newsletter_success']);

/**
 * Process form submissions based on the form_action field
 */
function processForm() {
    // Determine which form was submitted
    $formAction = $_POST['form_action'] ?? '';

    if ($formAction === 'contact_message') {
        processContactForm();
    } elseif ($formAction === 'newsletter_signup') {
        processNewsletterSignup();
    }
}

/**
 * Process the contact form submission
 */
function processContactForm() {
    // Get form data
    $name = $_POST['name'] ?? '';
    $email = $_POST['email'] ?? '';
    $message = $_POST['message'] ?? '';

    // Store the form data for redisplay in case of errors
    $_SESSION['form_data'] = [
        'name' => $name,
        'email' => $email,
        'message' => $message
    ];

    // Validate inputs
    $errors = [];

    if (empty($name)) {
        $errors['name'] = 'Name is required';
    }

    if (empty($email)) {
        $errors['email'] = 'Email is required';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors['email'] = 'Please enter a valid email address';
    }

    if (empty($message)) {
        $errors['message'] = 'Message is required';
    }

    // If there are errors, store them
    if (!empty($errors)) {
        $_SESSION['errors'] = $errors;
        return;
    }

    // No errors, process the form (in a real application, send email or save to database)
    // ...

    // Clear form data
    unset($_SESSION['form_data']);

    // Set success message
    $_SESSION['success_message'] = 'Thank you for your message! We will get back to you soon.';
}

/**
 * Process the newsletter signup
 */
function processNewsletterSignup() {
    // Get email
    $email = $_POST['newsletter_email'] ?? '';

    // Store for redisplay in case of errors
    $_SESSION['newsletter_email'] = $email;

    // Validate email
    $errors = [];

    if (empty($email)) {
        $errors['newsletter_email'] = 'Email is required';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors['newsletter_email'] = 'Please enter a valid email address';
    }

    // If there are errors, store them
    if (!empty($errors)) {
        $_SESSION['errors'] = $errors;
        return;
    }

    // No errors, process the newsletter signup
    // ...

    // Clear stored email
    unset($_SESSION['newsletter_email']);

    // Set success message
    $_SESSION['newsletter_success'] = 'Thank you for subscribing to our newsletter!';
}
