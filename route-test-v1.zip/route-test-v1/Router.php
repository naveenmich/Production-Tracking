<?php

/**
 * Router.php
 * 
 * Responsibilities:
 * - Define routes with path and page name
 * - Automatically handle GET and POST requests
 * - For GET: Render the page using Scaffold
 * - For POST: Include actions.php to handle form submissions
 */

require_once 'Scaffold.php';

class Router {
    private $routes = [];
    private $notFoundCallback;

    /**
     * Add a route
     * 
     * @param string $method HTTP method (GET, POST)
     * @param string $pattern URL pattern
     * @param string $pageName Name of the page directory
     */
    public function addRoute($method, $pattern, $pageName) {
        $pattern = '/^' . str_replace('/', '\/', $pattern) . '$/';
        $this->routes[$method][$pattern] = $pageName;
        return $this;
    }

    /**
     * Add a GET and POST route for a page
     * 
     * @param string $pattern URL pattern
     * @param string $pageName Name of the page directory
     */
    public function page($pattern, $pageName) {
        // Add GET route for rendering the page
        $this->addRoute('GET', $pattern, $pageName);

        // Add POST route for handling form submissions on the same page
        $this->addRoute('POST', $pattern, $pageName);

        return $this;
    }

    /**
     * Set a callback for when no routes match
     */
    public function notFound($pageName) {
        $this->notFoundCallback = $pageName;
        return $this;
    }

    /**
     * Match and run the appropriate route
     */
    public function run() {
        $requestMethod = $_SERVER['REQUEST_METHOD'];
        $requestUri = $_SERVER['REQUEST_URI'];

        // Remove query string from URI if present
        if (($pos = strpos($requestUri, '?')) !== false) {
            $requestUri = substr($requestUri, 0, $pos);
        }

        // Default to / if empty
        $requestUri = $requestUri ?: '/';

        // Check if method exists in routes
        if (isset($this->routes[$requestMethod])) {
            foreach ($this->routes[$requestMethod] as $pattern => $pageName) {
                if (preg_match($pattern, $requestUri, $matches)) {
                    // Remove the full match
                    array_shift($matches);

                    if ($requestMethod === 'GET') {
                        // For GET requests, render the page
                        Scaffold::getInstance()->renderPage($pageName);
                    } else if ($requestMethod === 'POST') {
                        // For POST requests, include actions.php
                        $actionsPath = 'views/pages/' . $pageName . '/actions.php';

                        if (file_exists($actionsPath)) {
                            include $actionsPath;

                            // If processForm function exists, call it
                            if (function_exists('processForm')) {
                                processForm();
                            }

                            // Redirect back to the same page
                            Scaffold::redirect($requestUri);
                        } else {
                            // No actions file found, just redirect
                            Scaffold::redirect($requestUri);
                        }
                    }

                    return;
                }
            }
        }

        // No routes matched, run the not found callback
        if ($this->notFoundCallback) {
            header("HTTP/1.0 404 Not Found");
            Scaffold::getInstance()->renderPage($this->notFoundCallback);
        } else {
            header("HTTP/1.0 404 Not Found");
            echo '404 Not Found';
        }
    }
}
