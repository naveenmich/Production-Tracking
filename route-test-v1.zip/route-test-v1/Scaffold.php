<?php

/**
 * Scaffold.php
 * 
 * Responsibilities:
 * - Add the header and footer
 * - Set page title
 * - Connect actions file for the corresponding page
 */

class Scaffold {
    // Page title
    private $title = 'My Website';

    // Singleton instance
    private static $instance = null;

    /**
     * Get the singleton instance
     */
    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Private constructor for singleton
     */
    private function __construct() {
        // Start session if not already started
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
    }

    /**
     * Set the page title
     */
    public function setTitle($title) {
        $this->title = $title;
        return $this;
    }

    /**
     * Get the page title
     */
    public function getTitle() {
        return $this->title;
    }

    /**
     * Render the page header
     */
    public function renderHeader() {
        // Get the current page path for highlighting the active menu item
        $currentPath = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);

        // Include the header
        include 'views/partials/header.php';
    }

    /**
     * Render the page footer
     */
    public function renderFooter() {
        // Include the footer
        include 'views/partials/footer.php';
    }

    /**
     * Render a page with its associated actions file
     * 
     * @param string $pageName The name of the page directory
     */
    public function renderPage($pageName) {
        // Construct the paths
        $pageDir = 'views/pages/' . $pageName;
        $pagePath = $pageDir . '/page.php';
        $actionsPath = $pageDir . '/actions.php';

        // Check if page exists
        if (!file_exists($pagePath)) {
            self::redirect('/not-found');
            return;
        }

        // Include the actions file if it exists
        if (file_exists($actionsPath)) {
            include_once $actionsPath;
        }

        // Start the page
        $this->renderHeader();

        // Include the page content
        include $pagePath;

        // End the page
        $this->renderFooter();
    }

    /**
     * Utility function to escape output
     */
    public static function escape($value) {
        return htmlspecialchars($value, ENT_QUOTES, 'UTF-8');
    }

    /**
     * Redirect to another page
     */
    public static function redirect($url, $statusCode = 302) {
        header('Location: ' . $url, true, $statusCode);
        exit;
    }
}
