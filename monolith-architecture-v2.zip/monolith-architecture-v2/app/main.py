from fastapi import FastAPI, Request
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from fastapi.responses import RedirectResponse
import datetime

# Import routes
from app.routes import landing_route, login_route

# Import middleware
from app.middleware.session_middleware import setup_session_middleware

# Import database service
from app.services.database_service import init_db

# Create FastAPI app
app = FastAPI(title="FastAPI Jinja2 SQLite Starter")

# Mount static files
app.mount("/static", StaticFiles(directory="app/public"), name="static")

# Set up templates
templates = Jinja2Templates(directory="app/templates")

# Add session middleware
app = setup_session_middleware(app)

# Include routers
app.include_router(landing_route.router)
app.include_router(login_route.router)

# Root redirect


@app.get("/")
async def root():
    return RedirectResponse(url="/landing")

# Make templates available to all routes


@app.middleware("http")
async def add_templates_to_request(request: Request, call_next):
    request.state.templates = templates
    response = await call_next(request)
    return response

# Add date to all templates


@app.middleware("http")
async def add_date_to_templates(request: Request, call_next):
    request.state.now = datetime.datetime.now()
    response = await call_next(request)
    return response

# Run on startup


@app.on_event("startup")
def startup_event():
    init_db()


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("app.main:app", host="0.0.0.0", port=8000, reload=True)
