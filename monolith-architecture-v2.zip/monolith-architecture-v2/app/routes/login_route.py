from fastapi import APIRouter, Request, Form, Depends, HTTPException, status
from fastapi.responses import HTMLResponse, RedirectResponse
from sqlalchemy.orm import Session
from app.services.database_service import get_db
from app.services.auth_service import authenticate_user, create_user, get_user_by_username
from app.middleware.auth_middleware import get_current_user
import datetime
from typing import Optional

router = APIRouter()


@router.get("/login", response_class=HTMLResponse)
async def login_page(
    request: Request,
    next: Optional[str] = None,
    db: Session = Depends(get_db)
):
    user = get_current_user(request, db)
    if user:
        return RedirectResponse(url=next or "/landing")

    return request.state.templates.TemplateResponse(
        "pages/login_page.html",
        {
            "request": request,
            "next": next,
            "now": datetime.datetime.now()
        }
    )


@router.post("/login", response_class=HTMLResponse)
async def login(
    request: Request,
    username: str = Form(...),
    password: str = Form(...),
    next: Optional[str] = Form(None),
    db: Session = Depends(get_db)
):
    user = authenticate_user(db, username, password)
    if not user:
        return request.state.templates.TemplateResponse(
            "pages/login_page.html",
            {
                "request": request,
                "next": next,
                "error": "Invalid username or password",
                "now": datetime.datetime.now()
            },
            status_code=status.HTTP_401_UNAUTHORIZED
        )

    # Set session
    request.session["user_id"] = user.id

    # Redirect to next page or landing
    return RedirectResponse(url=next or "/landing", status_code=status.HTTP_302_FOUND)


@router.get("/logout")
async def logout(request: Request):
    request.session.pop("user_id", None)
    return RedirectResponse(url="/landing")


@router.get("/register", response_class=HTMLResponse)
async def register_page(request: Request, db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if user:
        return RedirectResponse(url="/landing")

    return request.state.templates.TemplateResponse(
        "pages/register_page.html",
        {
            "request": request,
            "now": datetime.datetime.now()
        }
    )


@router.post("/register", response_class=HTMLResponse)
async def register(
    request: Request,
    username: str = Form(...),
    email: str = Form(...),
    password: str = Form(...),
    db: Session = Depends(get_db)
):
    # Check if user exists
    existing_user = get_user_by_username(db, username)
    if existing_user:
        return request.state.templates.TemplateResponse(
            "pages/register_page.html",
            {
                "request": request,
                "error": "Username already exists",
                "now": datetime.datetime.now()
            },
            status_code=status.HTTP_400_BAD_REQUEST
        )

    # Create new user
    user = create_user(db, username, email, password)

    # Set session
    request.session["user_id"] = user.id

    # Redirect to landing page
    return RedirectResponse(url="/landing", status_code=status.HTTP_302_FOUND)
