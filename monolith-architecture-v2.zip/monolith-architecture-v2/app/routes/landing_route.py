from fastapi import APIRouter, Request, Depends
from fastapi.responses import HTMLResponse
from sqlalchemy.orm import Session
from app.services.database_service import get_db
from app.middleware.auth_middleware import get_current_user
import datetime

router = APIRouter()


@router.get("/landing", response_class=HTMLResponse)
async def landing_page(
    request: Request,
    db: Session = Depends(get_db)
):
    user = get_current_user(request, db)
    return request.state.templates.TemplateResponse(
        "pages/landing_page.html",
        {
            "request": request,
            "user": user,
            "now": datetime.datetime.now()
        }
    )
