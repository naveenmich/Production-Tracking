from starlette.middleware.sessions import SessionMiddleware
import os
import secrets

# Generate a secure random secret key
SECRET_KEY = os.environ.get("SECRET_KEY", secrets.token_hex(32))


def setup_session_middleware(app):
    """
    Add session middleware to a FastAPI app
    """
    app.add_middleware(
        SessionMiddleware,
        secret_key=SECRET_KEY,
        session_cookie="session",
        max_age=14 * 24 * 60 * 60,  # 14 days in seconds
        same_site="lax",
        https_only=False  # Set to True in production with HTTPS
    )
    return app
