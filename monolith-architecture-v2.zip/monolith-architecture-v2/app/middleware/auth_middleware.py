from fastapi import Request, status, Depends
from fastapi.responses import RedirectResponse
from sqlalchemy.orm import Session
from app.services.database_service import get_db
from app.services.auth_service import get_user


def get_current_user(request: Request, db: Session = Depends(get_db)):
    user_id = request.session.get("user_id")
    if not user_id:
        return None

    user = get_user(db, user_id)
    return user


def login_required(request: Request, db: Session = Depends(get_db)):
    user_id = request.session.get("user_id")
    if not user_id:
        return RedirectResponse(
            url="/login?next=" + request.url.path,
            status_code=status.HTTP_302_FOUND
        )

    user = get_user(db, user_id)
    if not user:
        request.session.pop("user_id", None)
        return RedirectResponse(
            url="/login?next=" + request.url.path,
            status_code=status.HTTP_302_FOUND
        )

    return user
