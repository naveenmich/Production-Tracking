# FastAPI Monolith Starter (Simplified)

A clean and simplified monolithic web application starter using FastAPI with Jinja2 templates, SQLAlchemy, SQLite, and Tailwind CSS.

## Features

- **FastAPI**: Modern, fast (high-performance) web framework
- **Jinja2 Templates**: Server-side rendering with a powerful templating engine
- **SQLAlchemy with SQLite**: Simple yet powerful database setup
- **Tailwind CSS**: Utility-first CSS framework
- **jQuery**: Simple DOM manipulation and animations

## Project Structure

```
app/
├── main.py                  # FastAPI server start
├── database/
│   ├── models.py            # SQLAlchemy models
│   └── services.py          # SQLite database initiation
├── routes/
│   ├── home.py              # Home page route
│   ├── about.py             # About page route
│   └── users.py             # Users page and API routes
├── templates/
│   ├── base.html            # Base template
│   ├── macros/
│   │   └── forms.html       # Global form macros
│   └── pages/
│       ├── home/
│       │   └── page.html    # Home page template
│       ├── about/
│       │   └── page.html    # About page template
│       └── users/
│           ├── macros/
│           │   └── user_components.html  # User-specific macros
│           └── page.html                # Users page template
└── public/
    ├── images/
    └── css/
        └── styles.css       # Compiled CSS from Tailwind
```

## Setup Instructions

1. **Clone the repository**

```bash
git clone <repository-url>
cd fastapi-monolith
```

2. **Create and activate a virtual environment**

```bash
python -m venv venv
# On Windows
venv\Scripts\activate
# On Unix or MacOS
source venv/bin/activate
```

3. **Install Python dependencies**

```bash
pip install -r requirements.txt
```

4. **Install Node.js dependencies**

```bash
npm install
```

5. **Build Tailwind CSS**

```bash
npm run build:css
```

6. **Run the application**

```bash
# Development mode (with CSS watching)
npm run dev

# Or just the FastAPI server
python -m app.main
```

7. **Access the application**

Open your browser and go to `http://localhost:8000`

## Development Workflow

1. **Running in development mode**

```bash
npm run dev
```

This will start the FastAPI server and watch for CSS changes.

2. **Adding new routes**

Create a new file in the `app/routes/` directory similar to the existing route files.

3. **Creating new pages**

- Create a new directory in `app/templates/pages/`
- Add a `page.html` file for the page template
- Create a `macros/` subdirectory if you need page-specific components

## License

MIT