from fastapi import APIRouter, Request
from fastapi.templating import Jinja2Templates
from fastapi.responses import HTMLResponse
from pathlib import Path

router = APIRouter()
templates = Jinja2Templates(directory=Path("app/templates"))


@router.get("/", response_class=HTMLResponse)
async def home_page(request: Request):
    """Render the home page"""
    return templates.TemplateResponse(
        "pages/home/page.html",
        {"request": request, "current_year": request.state.current_year}
    )
