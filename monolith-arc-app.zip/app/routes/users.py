from fastapi import APIRouter, Request, Depends, Form, HTTPException
from fastapi.templating import Jinja2Templates
from fastapi.responses import HTMLResponse, RedirectResponse
from sqlalchemy.orm import Session
from pathlib import Path
from typing import Optional

from app.database.services import get_db
from app.database.models import User

router = APIRouter()
templates = Jinja2Templates(directory=Path("app/templates"))


@router.get("/users", response_class=HTMLResponse)
async def users_page(request: Request, db: Session = Depends(get_db)):
    """Render the users list page"""
    users = db.query(User).all()
    return templates.TemplateResponse(
        "pages/users/page.html",
        {
            "request": request,
            "users": users,
            "current_year": request.state.current_year
        }
    )


@router.post("/users")
async def create_user(
    request: Request,
    username: str = Form(...),
    email: str = Form(...),
    password: str = Form(...),
    is_active: Optional[bool] = Form(True),
    db: Session = Depends(get_db)
):
    """Create a new user"""
    # Check if email already exists
    db_user = db.query(User).filter(User.email == email).first()
    if db_user:
        # In a real app, you'd add a flash message here
        return RedirectResponse(url="/users", status_code=303)

    # In production, hash the password
    hashed_password = password  # Replace with proper hashing

    # Create new user
    db_user = User(
        username=username,
        email=email,
        hashed_password=hashed_password,
        is_active=is_active
    )

    db.add(db_user)
    db.commit()

    # Redirect back to users page
    return RedirectResponse(url="/users", status_code=303)


@router.post("/users/{user_id}/delete")
async def delete_user(
    user_id: int,
    request: Request,
    _method: str = Form(...),  # Hidden field to specify method
    db: Session = Depends(get_db)
):
    """Delete a user"""
    if _method.lower() != "delete":
        raise HTTPException(status_code=400, detail="Invalid method")

    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    db.delete(user)
    db.commit()

    return RedirectResponse(url="/users", status_code=303)


@router.post("/users/{user_id}/update")
async def update_user(
    user_id: int,
    request: Request,
    username: str = Form(...),
    email: str = Form(...),
    is_active: Optional[bool] = Form(False),
    _method: str = Form(...),  # Hidden field to specify method
    db: Session = Depends(get_db)
):
    """Update a user"""
    if _method.lower() != "put":
        raise HTTPException(status_code=400, detail="Invalid method")

    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    user.username = username
    user.email = email
    user.is_active = is_active

    db.commit()

    return RedirectResponse(url="/users", status_code=303)
