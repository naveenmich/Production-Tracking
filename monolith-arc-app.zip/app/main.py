from fastapi import FastAPI, Request
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from pathlib import Path
from contextlib import asynccontextmanager
from datetime import datetime

from app.database.services import create_db_and_tables
from app.routes import home, about, users

# Define lifespan event handler


@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup: Create database and tables
    create_db_and_tables()
    yield
    # Shutdown: Cleanup could go here

# Create FastAPI app instance with lifespan
app = FastAPI(title="FastAPI Monolith", lifespan=lifespan)

# Mount static files directory
app.mount("/static", StaticFiles(directory=Path("app/public")), name="static")

# Setup Jinja2 templates
templates = Jinja2Templates(directory=Path("app/templates"))

# Add template global variables


@app.middleware("http")
async def add_global_template_variables(request: Request, call_next):
    # Make current_year available to all templates
    request.state.current_year = datetime.now().year
    response = await call_next(request)
    return response

# Include route modules
app.include_router(home.router)
app.include_router(about.router)
app.include_router(users.router)

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("app.main:app", host="0.0.0.0", port=8000, reload=True)
