# Michelin ETD Year End Summary

A modern web application for processing and analyzing Electronic Transmission of Data (ETD) Excel files. Built with the Flash Feather framework, this application provides a streamlined workflow for uploading, processing, and accessing data for year-end reports.

## Features

- **Modern Dark-Themed UI**: Clean, responsive interface with a professional dark theme
- **Drag-and-Drop File Upload**: Easy Excel (.xlsx) file uploading with validation
- **Background Processing**: Asynchronous file processing with real-time status updates
- **File Management**: Track pending, processing, processed, and failed files
- **Real-Time Updates**: WebSocket-based live status updates without page refreshes
- **Data Warehouse Integration**: Processed data available for PowerBI dashboards
- **Robust Error Handling**: Clear feedback and recovery options for failed processing

## Tech Stack

This application is built with the Flash Feather framework, which combines:

- **Backend**:
  - Python FastAPI (for API endpoints and web server)
  - SQLAlchemy (for database ORM)
  - SQLite (for local data storage)
  - WebSockets (for real-time updates)

- **Frontend**:
  - Jinja2 (for HTML templates)
  - Lit.js (for web components)
  - Modern CSS (for responsive styling)
  - Font Awesome (for icons)

## Installation

### Prerequisites

- Python 3.9+
- Modern web browser (Chrome, Firefox, Edge)

### Setup

1. Create and activate a virtual environment:
   ```bash
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   ```

2. Install dependencies:
   ```bash
   pip install fastapi uvicorn sqlalchemy pydantic python-multipart jinja2 aiofiles websockets
   ```

3. Create necessary directories:
   ```bash
   mkdir -p app/uploads data-warehouse
   ```

## Usage

### Starting the Application

1. Run the FastAPI server:
   ```bash
   python -m app.main
   ```

2. Open your browser and navigate to:
   ```
   http://localhost:8000
   ```

### Workflow

1. **Upload Files**: 
   - Navigate to the Upload page
   - Drag and drop or browse for Excel (.xlsx) files
   - Click "Upload Files" to begin processing

2. **Monitor Processing**:
   - View real-time status on the Dashboard
   - Files progress through Pending → Processing → Processed (or Failed)
   - Failed files can be retried or deleted

3. **Access Processed Data**:
   - Processed data is available in the `data-warehouse` directory
   - Data can be accessed directly via URL: `http://localhost:8000/data/[path-to-file]`
   - Connect PowerBI to the data endpoints for dashboards

## Project Structure

```
etd-year-end-summary/
├── app/
│   ├── main.py                      # FastAPI application entry point
│   ├── database.py                  # Database configuration
│   ├── models.py                    # SQLAlchemy models
│   ├── public/                      # Static assets
│   │   └── js/
│   │       ├── components/          # Lit.js web components
│   │       └── utils/               # JavaScript utilities
│   ├── routes/                      # API and web routes
│   │   ├── web.py                   # Web page routes
│   │   ├── ws.py                    # WebSocket routes
│   │   └── api/                     # API endpoints
│   │       └── file_api.py
│   ├── schemas/                     # Pydantic schemas
│   │   └── file_schema.py
│   ├── services/                    # Backend services
│   │   └── extraction_service/      # ETD file processing logic
│   ├── templates/                   # Jinja2 templates
│   │   ├── base.html
│   │   └── pages/
│   │       ├── index.html
│   │       └── upload.html
│   └── uploads/                     # Temporary file storage
├── data-warehouse/                  # Processed data for PowerBI
│   ├── loss/
│   └── production/
├── venv/                            # Python virtual environment
├── requirements.txt                 # Python dependencies
└── README.md                        # This file
```

## Development

### Frontend Component Updates

When updating Lit.js components, you may need to perform a hard reload in your browser (Ctrl+F5 or Cmd+Shift+R) to clear the cache and see your changes.

### Adding New File Types

To support additional file types:
1. Update the validation function in `file-upload.js`
2. Modify the file processing logic in `extraction_service.py`

### Database Schema Changes

If you modify the database schema:
1. Update the SQLAlchemy models in `models.py`
2. Update corresponding Pydantic schemas in the `schemas` directory

## Data Processing Pipeline

1. **File Upload**: Files are uploaded and stored in the `app/uploads` directory
2. **Background Processing**: Files are processed asynchronously using the extraction service
3. **Data Warehouse**: Processed data is stored in the `data-warehouse` directory
4. **PowerBI Integration**: Data is made available for PowerBI via HTTP endpoints

## Troubleshooting

- **Files stuck in Processing state**: Restart the application to reset stuck files
- **Upload button not working**: Try using drag and drop instead
- **WebSocket connection issues**: Check browser console for errors

## Contributors

- Kasun Dulara | 5585 - App Dev
- Naveen Prabhoda | 5393 - PowerBi Dev
- Anusha Rajaguru | 5584 - PowerBi Dev

## Acknowledgements

- Built with the Flash Feather framework
- Uses Font Awesome for icons
- Inspired by modern web application design principles