from fastapi import APIRouter, WebSocket, WebSocketDisconnect
from fastapi.responses import HTMLResponse
import json
import asyncio
from typing import List, Dict, Any

router = APIRouter()

# Store active WebSocket connections
active_connections: List[WebSocket] = []

# Broadcast message to all connected clients


async def broadcast_message(message: Dict[str, Any]):
    disconnected = []

    for i, connection in enumerate(active_connections):
        try:
            await connection.send_text(json.dumps(message))
        except Exception as e:
            print(f"Error broadcasting message: {e}")
            disconnected.append(i)

    # Remove disconnected connections
    for i in sorted(disconnected, reverse=True):
        try:
            active_connections.pop(i)
        except IndexError:
            pass


@router.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    await websocket.accept()
    active_connections.append(websocket)

    try:
        # When a client connects, immediately send them the current files list
        from app.database import get_db
        from app.models import File

        db = next(get_db())

        # Get all files
        files = db.query(File).all()
        file_dicts = [file.to_dict() for file in files]

        # Calculate stats
        pending_count = sum(1 for file in files if file.status == "Pending")
        processing_count = sum(
            1 for file in files if file.status == "Processing")
        processed_count = sum(
            1 for file in files if file.status == "Processed")
        failed_count = sum(1 for file in files if file.status == "Failed")

        stats = {
            "pending": pending_count,
            "processing": processing_count,
            "processed": processed_count,
            "failed": failed_count,
            "total": len(files)
        }

        # Send initial data
        await websocket.send_text(json.dumps({
            "type": "initial_data",
            "data": {
                "files": file_dicts,
                "counts": stats
            }
        }))

        # Keep connection alive and process any incoming messages
        while True:
            data = await websocket.receive_text()
            # Process any client-side commands if needed
            # Here we just acknowledge receipt
            await websocket.send_text(json.dumps({
                "type": "ack",
                "data": {"message": "Message received"}
            }))

    except WebSocketDisconnect:
        if websocket in active_connections:
            active_connections.remove(websocket)
    except Exception as e:
        print(f"WebSocket error: {e}")
        if websocket in active_connections:
            active_connections.remove(websocket)
