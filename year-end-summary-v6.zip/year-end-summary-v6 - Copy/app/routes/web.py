from fastapi import APIRouter, Request
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
from pathlib import Path

router = APIRouter()

templates = Jinja2Templates(directory=Path(
    __file__).parent.parent / "templates")


@router.get("/", response_class=HTMLResponse)
async def home(request: Request):
    return templates.TemplateResponse(
        "pages/index.html",
        {"request": request}
    )


@router.get("/upload", response_class=HTMLResponse)
async def upload_page(request: Request):
    return templates.TemplateResponse(
        "pages/upload.html",
        {"request": request}
    )


@router.get("/data-browser", response_class=HTMLResponse)
async def data_browser(request: Request):
    data_path = Path(__file__).parent.parent.parent / "data-warehouse"

    # Collect files and organize them
    files = []
    for filepath in data_path.glob('**/*.csv'):
        relative_path = filepath.relative_to(data_path)
        url_path = f"/data/{relative_path.as_posix()}"
        files.append({
            "name": filepath.name,
            "path": str(relative_path),
            "url": url_path
        })

    return templates.TemplateResponse(
        "pages/data-browser.html",
        {"request": request, "files": files}
    )
