from fastapi import APIRouter, Depends, UploadFile, File, HTTPException
from sqlalchemy.orm import Session
from sqlalchemy import func
import os
import hashlib
from pathlib import Path
import asyncio
import threading
import time
import queue

from app.database import get_db, SessionLocal
from app.models import File as FileModel
from app.routes.ws import broadcast_message
from app.services.extraction_service.extraction_service import ExtractionService

router = APIRouter(prefix="/api")

# Upload directory
UPLOAD_DIR = Path(__file__).parent.parent.parent / "uploads"
UPLOAD_DIR.mkdir(exist_ok=True)

# File processing queue and worker thread
file_queue = queue.Queue()
worker_thread = None
worker_running = False

# Helper functions


def generate_file_hash(filename, content):
    """Generate a unique hash for a file based on its name and content."""
    hash_obj = hashlib.md5()
    hash_obj.update(f"{filename}{content}".encode())
    return hash_obj.hexdigest()


def get_file_stats():
    """Get file counts by status."""
    db = SessionLocal()
    try:
        pending_count = db.query(func.count(FileModel.hash)).filter(
            FileModel.status == "Pending").scalar()
        processing_count = db.query(func.count(FileModel.hash)).filter(
            FileModel.status == "Processing").scalar()
        processed_count = db.query(func.count(FileModel.hash)).filter(
            FileModel.status == "Processed").scalar()
        failed_count = db.query(func.count(FileModel.hash)).filter(
            FileModel.status == "Failed").scalar()

        return {
            "pending": pending_count,
            "processing": processing_count,
            "processed": processed_count,
            "failed": failed_count,
            "total": pending_count + processing_count + processed_count + failed_count
        }
    finally:
        db.close()


def validate_excel_file(filename):
    """Validate that the file is an Excel file (.xlsx)."""
    return filename.lower().endswith('.xlsx')

# Process a single file


def process_single_file(file_hash):
    """Process a single file with proper error handling."""
    db = SessionLocal()

    try:
        # Get the file from database
        file = db.query(FileModel).filter(FileModel.hash == file_hash).first()

        # Skip if file not found or not in pending status
        if not file or file.status != "Pending":
            return

        # Update status to Processing
        file.status = "Processing"
        db.commit()

        # Send WebSocket update
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        loop.run_until_complete(broadcast_message(
            {"type": "status_update", "data": file.to_dict()}))

        try:
            # Initialize the extraction service
            extraction_service = ExtractionService()

            # Process the file
            extraction_service.process_file(file.file_path)

            # Update status to Processed
            file.status = "Processed"

            # Delete the file from disk after successful processing
            if os.path.exists(file.file_path):
                try:
                    os.remove(file.file_path)
                except Exception:
                    pass

        except Exception as e:
            # Update status to Failed
            file.status = "Failed"
            file.error = str(e)

        # Commit changes and send WebSocket update
        db.commit()
        loop.run_until_complete(broadcast_message(
            {"type": "status_update", "data": file.to_dict()}))
        loop.run_until_complete(broadcast_message(
            {"type": "stats_update", "data": get_file_stats()}))
        loop.close()

    except Exception as e:
        # Handle any unexpected errors
        try:
            # Try to mark file as failed
            file = db.query(FileModel).filter(
                FileModel.hash == file_hash).first()
            if file:
                file.status = "Failed"
                file.error = f"Unexpected error: {str(e)}"
                db.commit()

                # Try to send update
                loop = asyncio.new_event_loop()
                asyncio.set_event_loop(loop)
                loop.run_until_complete(broadcast_message(
                    {"type": "status_update", "data": file.to_dict()}))
                loop.run_until_complete(broadcast_message(
                    {"type": "stats_update", "data": get_file_stats()}))
                loop.close()
        except:
            pass

    finally:
        # Always close the database session
        db.close()

# Main worker thread function


def file_processor_worker():
    """Single worker thread that processes files one at a time."""
    global worker_running

    worker_running = True

    while worker_running:
        try:
            # Get the next file hash from the queue with a timeout
            try:
                file_hash = file_queue.get(timeout=5)
            except queue.Empty:
                # Check for pending files and add them to the queue
                db = SessionLocal()
                pending_files = db.query(FileModel).filter(
                    FileModel.status == "Pending").all()
                db.close()

                if pending_files:
                    for file in pending_files:
                        file_queue.put(file.hash)

                continue

            # Process the file
            process_single_file(file_hash)

            # Mark task as done
            file_queue.task_done()

        except Exception:
            # Prevent CPU thrashing if there's a recurring error
            time.sleep(2)

# Reset stuck processing files


def reset_stuck_processing_files():
    """Reset any files stuck in 'Processing' status to 'Failed'."""
    db = SessionLocal()
    try:
        stuck_files = db.query(FileModel).filter(
            FileModel.status == "Processing").all()

        if stuck_files:
            for file in stuck_files:
                file.status = "Failed"
                file.error = "Processing was interrupted. Please retry."

            db.commit()

            # Broadcast updates
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            for file in stuck_files:
                loop.run_until_complete(broadcast_message({
                    "type": "status_update",
                    "data": file.to_dict()
                }))

            loop.run_until_complete(broadcast_message({
                "type": "stats_update",
                "data": get_file_stats()
            }))
            loop.close()
    except Exception:
        pass
    finally:
        db.close()

# Queue existing pending files


def queue_existing_pending_files():
    """Add any existing pending files to the queue."""
    db = SessionLocal()
    try:
        pending_files = db.query(FileModel).filter(
            FileModel.status == "Pending").all()

        if pending_files:
            for file in pending_files:
                file_queue.put(file.hash)

    except Exception:
        pass
    finally:
        db.close()

# Start the worker thread


def ensure_worker_running():
    """Ensure the worker thread is running."""
    global worker_thread, worker_running

    if worker_thread and worker_thread.is_alive():
        return

    # Reset any stuck processing files
    reset_stuck_processing_files()

    # Queue any pending files
    queue_existing_pending_files()

    # Start a new worker thread
    worker_thread = threading.Thread(target=file_processor_worker, daemon=True)
    worker_thread.start()

# Add files to the processing queue


def enqueue_files_for_processing(file_hashes):
    """Add files to the processing queue."""
    ensure_worker_running()

    for file_hash in file_hashes:
        file_queue.put(file_hash)


@router.post("/upload")
async def upload_files(files: list[UploadFile] = File(...), db: Session = Depends(get_db)):
    """Upload files and add them to the processing queue."""
    if not files:
        raise HTTPException(status_code=400, detail="No files provided")

    processed_files = []
    file_hashes = []

    for upload_file in files:
        # Validate file extension
        if not validate_excel_file(upload_file.filename):
            processed_files.append({
                "filename": upload_file.filename,
                "status": "skipped",
                "message": "Only Excel files (.xlsx) are allowed"
            })
            continue

        content = await upload_file.read()

        # Generate a unique hash for this file
        file_hash = generate_file_hash(upload_file.filename, content)

        # Check if this file was already uploaded
        existing_file = db.query(FileModel).filter(
            FileModel.hash == file_hash).first()
        if existing_file:
            processed_files.append({
                "filename": upload_file.filename,
                "status": "skipped",
                "message": "File already exists"
            })
            continue

        try:
            # Save the file to disk
            file_path = os.path.join(
                UPLOAD_DIR, f"{file_hash}_{upload_file.filename}")
            with open(file_path, "wb") as f:
                f.write(content)

            # Add file to database
            new_file = FileModel(
                hash=file_hash,
                file_name=upload_file.filename,
                file_path=file_path,
                size=len(content),
                status="Pending"
            )
            db.add(new_file)
            db.commit()

            file_hashes.append(file_hash)
            processed_files.append({
                "filename": upload_file.filename,
                "status": "uploaded",
                "hash": file_hash
            })

        except Exception as e:
            processed_files.append({
                "filename": upload_file.filename,
                "status": "error",
                "message": str(e)
            })

    # Start background processing
    if file_hashes:
        enqueue_files_for_processing(file_hashes)

    # Send updated file list to all clients
    all_files = db.query(FileModel).all()
    await broadcast_message({
        "type": "files_list",
        "data": {"files": [f.to_dict() for f in all_files], "counts": get_file_stats()}
    })

    return {"processed_files": processed_files}


@router.get("/files")
async def get_files(db: Session = Depends(get_db)):
    """Get all files with their status."""
    files = db.query(FileModel).all()
    return {"files": [f.to_dict() for f in files], "counts": get_file_stats()}


@router.post("/retry/{file_hash}")
async def retry_file(file_hash: str, db: Session = Depends(get_db)):
    """Retry processing a failed file."""
    file = db.query(FileModel).filter(FileModel.hash == file_hash).first()
    if not file:
        raise HTTPException(status_code=404, detail="File not found")

    if file.status != "Failed":
        return {"message": "Only failed files can be retried"}

    # Reset file status
    file.status = "Pending"
    file.error = None
    db.commit()

    # Broadcast status update
    await broadcast_message({"type": "status_update", "data": file.to_dict()})

    # Process in background
    enqueue_files_for_processing([file_hash])

    return {"message": "File queued for retry"}


@router.delete("/clean/{file_hash}")
async def delete_file(file_hash: str, db: Session = Depends(get_db)):
    """Delete a file from the system."""
    file = db.query(FileModel).filter(FileModel.hash == file_hash).first()
    if not file:
        raise HTTPException(status_code=404, detail="File not found")

    # Delete file from disk if it exists
    if os.path.exists(file.file_path):
        os.remove(file.file_path)

    # Delete from database
    db.delete(file)
    db.commit()

    # Broadcast update
    await broadcast_message({
        "type": "file_deleted",
        "data": {"hash": file_hash, "counts": get_file_stats()}
    })

    return {"message": "File deleted"}


@router.get("/queue-status")
async def get_queue_status():
    """Get the current status of the file processing queue."""
    return {
        "queue_size": file_queue.qsize(),
        "worker_running": worker_running and worker_thread and worker_thread.is_alive()
    }


def stop_workers():
    """Stop worker threads on application shutdown."""
    global worker_running
    worker_running = False
    if worker_thread:
        worker_thread.join(timeout=2)
