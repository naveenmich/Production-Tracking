DEFAULT_CONFIG = {
    'output_dir': 'data-warehouse',
    'monthly_subdir': 'loss/monthly',
    'yearly_file': 'loss/yearly-loss.csv',
    'monthly_nonzero_file': 'loss/monthly-loss-non-zero.csv',
    'production_file': 'production/monthly-production.csv',
    'lines_mapping_file': 'app/services/extraction_service/lines.csv',
    'loss_mapping_file': 'app/services/extraction_service/loss.csv'
}

PRODUCTION_ROWS = {
    'schedule_pcs': 130,
    'production_pcs': 131,
    'schedule_tons': 133,
    'production_tons': 134,
    'schedule_kg': 136,
    'production_kg': 137
}

PLANT_HIERARCHY = {
    "L-1": {"plant": "ETD-1", "zone": "Zone-A", "loop": "Loop-5"},
    "L-5": {"plant": "ETD-1", "zone": "Zone-A", "loop": "Loop-6"},
    "L-6": {"plant": "ETD-1", "zone": "Zone-A", "loop": "Loop-6"},
    "L-7": {"plant": "ETD-1", "zone": "Zone-A", "loop": "Loop-6"},
    "L-8": {"plant": "ETD-1", "zone": "Zone-A", "loop": "Loop-6"},
    "L-PR": {"plant": "ETD-1", "zone": "Zone-A", "loop": "Loop-6"},
    "L-9": {"plant": "ETD-1", "zone": "Zone-A", "loop": "Loop-4"},
    "L-10": {"plant": "ETD-1", "zone": "Zone-A", "loop": "Loop-4"},
    "L-13": {"plant": "ETD-1", "zone": "Zone-B", "loop": "Loop-10"},
    "L-14": {"plant": "ETD-1", "zone": "Zone-B", "loop": "Loop-10"},
    "L-15": {"plant": "ETD-1", "zone": "Zone-B", "loop": "Loop-9"}
}
