#!/usr/bin/env python3
import pandas as pd
import os
import re
import csv
from datetime import datetime
from openpyxl import load_workbook
from typing import Dict, List, Tuple, Optional
from app.services.extraction_service.extraction_core import DEFAULT_CONFIG, PRODUCTION_ROWS, PLANT_HIERARCHY


class ExtractionService:

    def __init__(self):
        self.config = DEFAULT_CONFIG.copy()

        os.makedirs(self.config['output_dir'], exist_ok=True)

        self.lines_df = None
        self.loss_df = None
        self.line_shift_map = {}
        self.dept_reason_map = {}

        self._load_mappings()

    def _load_mappings(self) -> None:
        try:
            lines_file = self.config.get('lines_mapping_file', 'lines.csv')
            self.lines_df = pd.read_csv(lines_file)

            self.line_shift_map = {}
            for _, row in self.lines_df.iterrows():
                line_cell = row['line-cell']
                line_value = row['line-value']
                shift_value = row['shift-value']
                column = ''.join(filter(str.isalpha, line_cell))
                self.line_shift_map[(line_value, shift_value)] = column

            loss_file = self.config.get('loss_mapping_file', 'loss.csv')
            self.loss_df = pd.read_csv(loss_file)

            self._create_dept_reason_map()

        except FileNotFoundError as e:
            raise FileNotFoundError(
                f"Required mapping file not found: {str(e)}")
        except pd.errors.EmptyDataError:
            raise ValueError("One of the mapping files is empty")
        except pd.errors.ParserError:
            raise ValueError(
                "Error parsing CSV mapping files - check file format")
        except Exception as e:
            raise Exception(f"Failed to load mappings: {str(e)}")

    def _create_dept_reason_map(self) -> None:
        self.dept_reason_map = {}
        current_dept = ""

        loss_df_sorted = self.loss_df.sort_values(
            by=['celldepartment-cell', 'reason-cell'])

        for _, row in loss_df_sorted.iterrows():
            dept_value = row['department-value'].strip() if isinstance(
                row['department-value'], str) else row['department-value']
            reason_cell = row['reason-cell']
            reason_value = row['reason-value'].strip() if isinstance(
                row['reason-value'], str) else row['reason-value']

            if dept_value:
                current_dept = dept_value

            row_num = ''.join(filter(str.isdigit, reason_cell))

            if not reason_value:
                continue

            self.dept_reason_map[row_num] = {
                "department": current_dept if current_dept else "Unknown",
                "reason": reason_value
            }

    def _get_year_month(self, file_path: str, wb) -> Tuple[str, str]:
        filename = os.path.basename(file_path)

        year_match = re.search(r'20\d{2}', filename)
        year = year_match.group(0) if year_match else None

        month_match = re.search(
            r'(January|February|March|April|May|June|July|August|September|October|November|December)',
            filename, re.IGNORECASE)
        month = month_match.group(1).capitalize() if month_match else None

        if not year or not month:
            try:
                ws = wb.active
                for row in range(1, min(10, ws.max_row + 1)):
                    for col in range(1, min(10, ws.max_column + 1)):
                        cell_value = ws.cell(row=row, column=col).value
                        if isinstance(cell_value, str):
                            year_match = re.search(r'20\d{2}', cell_value)
                            month_match = re.search(
                                r'(January|February|March|April|May|June|July|August|September|October|November|December)',
                                cell_value, re.IGNORECASE)
                            if year_match and month_match:
                                return year_match.group(0), month_match.group(1).capitalize()
            except Exception:
                pass

        if not year or not month:
            current_date = datetime.now()
            year = str(current_date.year)
            month = current_date.strftime('%B')

        return year, month

    def _extract_data_from_excel(self, excel_file_path: str) -> Tuple[Optional[List[Dict]], Optional[List[Dict]]]:
        try:
            wb = load_workbook(filename=excel_file_path, data_only=True)
            ws = wb.active
        except Exception as e:
            raise Exception(f"Failed to load Excel file: {str(e)}")

        year, month = self._get_year_month(excel_file_path, wb)

        production_data = []

        for (line, shift), column in self.line_shift_map.items():
            hierarchy = PLANT_HIERARCHY.get(
                line, {"plant": "Unknown", "zone": "Unknown", "loop": "Unknown"})

            record = {
                'year': year,
                'month': month,
                'plant': hierarchy['plant'],
                'zone': hierarchy['zone'],
                'loop': hierarchy['loop'],
                'line': line,
                'shift': shift
            }

            for field, row_num in PRODUCTION_ROWS.items():
                cell_address = f"{column}{row_num}"
                try:
                    cell = ws[cell_address]
                    value = cell.value

                    if value is None:
                        value = 0
                    elif isinstance(value, (int, float)):
                        pass
                    else:
                        try:
                            value = float(value)
                        except:
                            value = 0

                    record[field] = value
                except Exception:
                    record[field] = 0

            production_data.append(record)

        loss_data = []
        non_zero_count = 0

        for row_num, reason_info in self.dept_reason_map.items():
            department = reason_info["department"]
            reason = reason_info["reason"]

            for (line, shift), column in self.line_shift_map.items():
                cell_address = f"{column}{row_num}"

                try:
                    cell = ws[cell_address]
                    value = cell.value

                    if value is None:
                        value = 0
                    elif isinstance(value, (int, float)):
                        pass
                    else:
                        try:
                            value = float(value)
                        except:
                            value = 0

                    if value > 0:
                        non_zero_count += 1
                except Exception:
                    value = 0

                hierarchy = PLANT_HIERARCHY.get(
                    line, {"plant": "Unknown", "zone": "Unknown", "loop": "Unknown"})

                loss_data.append({
                    'year': year,
                    'month': month,
                    'plant': hierarchy['plant'],
                    'zone': hierarchy['zone'],
                    'loop': hierarchy['loop'],
                    'line': line,
                    'shift': shift,
                    'department': department,
                    'reason': reason,
                    'loss': value
                })

        return production_data, loss_data

    def _update_monthly_nonzero_dataset(self, output_data: List[Dict]) -> None:
        monthly_file = os.path.join(
            self.config['output_dir'], self.config['monthly_nonzero_file'])
        os.makedirs(os.path.dirname(monthly_file), exist_ok=True)

        monthly_columns = ["year", "month", "plant", "zone",
                           "loop", "line", "shift", "department", "reason", "loss"]

        non_zero_data = [record for record in output_data
                         if isinstance(record.get('loss'), (int, float)) and float(record.get('loss', 0)) > 0]

        if not non_zero_data:
            return

        monthly_data = []
        if os.path.exists(monthly_file):
            try:
                with open(monthly_file, 'r', newline='', encoding='utf-8') as csvfile:
                    reader = csv.DictReader(csvfile)
                    monthly_data = list(reader)
            except Exception as e:
                raise Exception(
                    f"Failed to read monthly non-zero dataset: {str(e)}")

        for record in non_zero_data:
            record_key = (
                record['year'], record['month'], record['plant'], record['zone'],
                record['loop'], record['line'], record['shift'],
                record['department'], record['reason']
            )

            exists = False
            for existing_record in monthly_data:
                existing_key = (
                    existing_record['year'], existing_record['month'],
                    existing_record['plant'], existing_record['zone'],
                    existing_record['loop'], existing_record['line'],
                    existing_record['shift'], existing_record['department'],
                    existing_record['reason']
                )

                if record_key == existing_key:
                    existing_record['loss'] = record['loss']
                    exists = True
                    break

            if not exists:
                monthly_data.append(
                    {col: record[col] for col in monthly_columns if col in record})

        try:
            with open(monthly_file, 'w', newline='', encoding='utf-8') as csvfile:
                writer = csv.DictWriter(csvfile, fieldnames=monthly_columns)
                writer.writeheader()
                writer.writerows(monthly_data)
        except Exception as e:
            raise Exception(
                f"Failed to write monthly non-zero dataset: {str(e)}")

    def _update_yearly_dataset(self, output_data: List[Dict]) -> None:
        yearly_file = os.path.join(
            self.config['output_dir'], self.config['yearly_file'])
        os.makedirs(os.path.dirname(yearly_file), exist_ok=True)

        yearly_columns = ["year", "plant", "zone", "loop",
                          "line", "shift", "department", "reason", "loss"]

        yearly_data = []
        if os.path.exists(yearly_file):
            try:
                with open(yearly_file, 'r', newline='', encoding='utf-8') as csvfile:
                    reader = csv.DictReader(csvfile)
                    yearly_data = list(reader)
            except Exception as e:
                raise Exception(f"Failed to read yearly dataset: {str(e)}")

        for record in yearly_data:
            try:
                record['loss'] = float(record['loss'])
            except (ValueError, TypeError):
                record['loss'] = 0

        for record in output_data:
            record_key = (
                record['year'], record['plant'], record['zone'],
                record['loop'], record['line'], record['shift'],
                record['department'], record['reason']
            )

            found = False
            for yearly_record in yearly_data:
                yearly_key = (
                    yearly_record['year'], yearly_record['plant'],
                    yearly_record['zone'], yearly_record['loop'],
                    yearly_record['line'], yearly_record['shift'],
                    yearly_record['department'], yearly_record['reason']
                )

                if record_key == yearly_key:
                    try:
                        yearly_record['loss'] = float(
                            yearly_record['loss']) + float(record['loss'])
                    except (ValueError, TypeError):
                        yearly_record['loss'] = float(record['loss'])
                    found = True
                    break

            if not found:
                yearly_data.append(
                    {col: record[col] for col in yearly_columns if col in record})

        try:
            with open(yearly_file, 'w', newline='', encoding='utf-8') as csvfile:
                writer = csv.DictWriter(csvfile, fieldnames=yearly_columns)
                writer.writeheader()
                writer.writerows(yearly_data)
        except Exception as e:
            raise Exception(f"Failed to write yearly dataset: {str(e)}")

    def _update_production_dataset(self, output_data: List[Dict]) -> None:
        production_file = os.path.join(
            self.config['output_dir'], self.config['production_file'])
        os.makedirs(os.path.dirname(production_file), exist_ok=True)

        production_columns = [
            "year", "month", "plant", "zone", "loop", "line", "shift",
            "schedule_pcs", "production_pcs", "schedule_tons", "production_tons",
            "schedule_kg", "production_kg"
        ]

        production_data = []
        if os.path.exists(production_file):
            try:
                with open(production_file, 'r', newline='', encoding='utf-8') as csvfile:
                    reader = csv.DictReader(csvfile)
                    production_data = list(reader)
            except Exception as e:
                raise Exception(f"Failed to read production dataset: {str(e)}")

        for record in production_data:
            for field in production_columns:
                if field not in ["year", "month", "plant", "zone", "loop", "line", "shift"]:
                    try:
                        if record[field]:
                            record[field] = float(record[field])
                        else:
                            record[field] = 0
                    except (ValueError, TypeError, KeyError):
                        record[field] = 0

        new_records = 0
        updated_records = 0

        for record in output_data:
            full_record = {field: 0 for field in production_columns}
            full_record.update(
                {key: val for key, val in record.items() if key in production_columns})

            record_key = (
                str(full_record.get('year', '')), str(
                    full_record.get('month', '')),
                str(full_record.get('plant', '')), str(
                    full_record.get('zone', '')),
                str(full_record.get('loop', '')), str(
                    full_record.get('line', '')),
                str(full_record.get('shift', ''))
            )

            exists = False
            for existing_record in production_data:
                existing_key = (
                    str(existing_record.get('year', '')), str(
                        existing_record.get('month', '')),
                    str(existing_record.get('plant', '')), str(
                        existing_record.get('zone', '')),
                    str(existing_record.get('loop', '')), str(
                        existing_record.get('line', '')),
                    str(existing_record.get('shift', ''))
                )

                if record_key == existing_key:
                    for field in production_columns:
                        if field in full_record:
                            existing_record[field] = full_record[field]
                    exists = True
                    updated_records += 1
                    break

            if not exists:
                production_data.append(full_record)
                new_records += 1

        try:
            with open(production_file, 'w', newline='', encoding='utf-8') as csvfile:
                writer = csv.DictWriter(csvfile, fieldnames=production_columns)
                writer.writeheader()
                writer.writerows(production_data)
        except Exception as e:
            raise Exception(f"Failed to write production dataset: {str(e)}")

    def process_file(self, excel_file_path: str) -> bool:
        try:
            production_data, loss_data = self._extract_data_from_excel(
                excel_file_path)

            if production_data is None or loss_data is None:
                raise Exception("No data extracted from the file.")

            year = production_data[0]['year']
            month = production_data[0]['month']

            monthly_subdir = os.path.join(
                self.config['output_dir'], self.config['monthly_subdir'], year)
            os.makedirs(monthly_subdir, exist_ok=True)

            monthly_file = f"{year}-{month.lower()}-loss.csv"
            monthly_path = os.path.join(monthly_subdir, monthly_file)

            try:
                with open(monthly_path, 'w', newline='', encoding='utf-8') as csvfile:
                    fieldnames = ["year", "month", "plant", "zone", "loop",
                                  "line", "shift", "department", "reason", "loss"]
                    writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
                    writer.writeheader()
                    writer.writerows(loss_data)
            except Exception as e:
                raise Exception(f"Failed to write monthly loss file: {str(e)}")

            self._update_yearly_dataset(loss_data)
            self._update_monthly_nonzero_dataset(loss_data)
            self._update_production_dataset(production_data)

            return True
        except Exception as e:
            raise Exception(
                f"Failed to process file {excel_file_path}: {str(e)}")
