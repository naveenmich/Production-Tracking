import { LitElement, html } from 'https://esm.run/lit';
import { initWebSocket, addEventListener, EVENT_TYPES } from '../utils/websocket_utils.js';

class ProcessingIndicator extends LitElement {
  static get properties() {
    return {
      processingFiles: { type: Array },
      expanded: { type: Boolean }
    };
  }

  constructor() {
    super();
    this.processingFiles = [];
    this.expanded = false;
  }

  // Disable Shadow DOM to access global styles
  createRenderRoot() {
    return this;
  }

  connectedCallback() {
    super.connectedCallback();
    initWebSocket();

    // Listen for status updates
    addEventListener(EVENT_TYPES.STATUS_UPDATE, (data) => {
      if (data.status === 'Processing') {
        // Add to processing files if not already there
        if (!this.processingFiles.some(file => file.hash === data.hash)) {
          this.processingFiles = [...this.processingFiles, data];
        }
      } else {
        // Remove from processing files if status changed
        this.processingFiles = this.processingFiles.filter(
          file => file.hash !== data.hash
        );
      }
      // Update expanded state based on whether we have processing files
      this.expanded = this.processingFiles.length > 0;
    });

    // Initial data
    addEventListener(EVENT_TYPES.INITIAL_DATA, (data) => {
      if (data.files) {
        this.processingFiles = data.files.filter(
          file => file.status === 'Processing'
        );
        this.expanded = this.processingFiles.length > 0;
      }
    });

    // Also listen for files list updates
    addEventListener(EVENT_TYPES.FILES_LIST, (data) => {
      if (data.files) {
        this.processingFiles = data.files.filter(
          file => file.status === 'Processing'
        );
        this.expanded = this.processingFiles.length > 0;
      }
    });
  }

  render() {
    return html`
      <div class="processing-indicator-wrapper ${this.expanded ? 'expanded' : 'collapsed'}">
        <div class="processing-indicator">
          <div class="indicator-content">
            <div class="processing-icon">
              <i class="fas fa-cogs fa-spin"></i>
            </div>
            <div class="processing-text">
              <span>Processing ${this.processingFiles.length} file${this.processingFiles.length !== 1 ? 's' : ''}...</span>
              ${this.processingFiles.length === 1 ?
        html`<div class="current-file">${this.processingFiles[0].file_name}</div>` :
        ''}
            </div>
          </div>
        </div>
      </div>

      <style>
        .processing-indicator-wrapper {
          overflow: hidden;
          transition: all 0.5s ease;
          margin-bottom: 0;
          opacity: 0;
        }
        
        .processing-indicator-wrapper.expanded {
          max-height: 100px;
          margin-bottom: 1.5rem;
          opacity: 1;
        }
        
        .processing-indicator-wrapper.collapsed {
          max-height: 0;
          margin-bottom: 0;
          opacity: 0;
        }
        
        .processing-indicator {
          background-color: var(--accent);
          color: var(--bg-primary);
          border-radius: 8px;
          padding: 1rem;
          animation: pulse 1.5s ease-in-out infinite;
        }
        
        .indicator-content {
          display: flex;
          align-items: center;
          gap: 1rem;
        }
        
        .processing-icon {
          font-size: 1.5rem;
        }
        
        .processing-text {
          font-weight: 500;
        }
        
        .current-file {
          font-size: 0.9rem;
          opacity: 0.9;
          margin-top: 0.25rem;
        }
        
        @keyframes pulse {
          0% { opacity: 0.9; }
          50% { opacity: 1; }
          100% { opacity: 0.9; }
        }
      </style>
    `;
  }
}

customElements.define('processing-indicator', ProcessingIndicator);