import { LitElement, html } from 'https://esm.run/lit';
import { uploadFiles } from '../utils/api_utils.js';
import { formatFileSize } from '../utils/file_utils.js';

class FileUpload extends LitElement {
  static get properties() {
    return {
      files: { type: Array },
      dragging: { type: Boolean },
      uploading: { type: Boolean },
      uploadProgress: { type: Number },
      uploadComplete: { type: Boolean },
      uploadError: { type: String },
      invalidFiles: { type: Array }
    };
  }

  constructor() {
    super();
    this.files = [];
    this.dragging = false;
    this.uploading = false;
    this.uploadProgress = 0;
    this.uploadComplete = false;
    this.uploadError = null;
    this.invalidFiles = [];
  }

  // Disable Shadow DOM to access global styles
  createRenderRoot() {
    return this;
  }

  // Check if file is valid Excel file
  isValidExcelFile(file) {
    const fileName = file.name.toLowerCase();
    return fileName.endsWith('.xlsx');
  }

  // Handle drag events
  handleDragEnter(e) {
    e.preventDefault();
    e.stopPropagation();
    this.dragging = true;
  }

  handleDragOver(e) {
    e.preventDefault();
    e.stopPropagation();
    this.dragging = true;
  }

  handleDragLeave(e) {
    e.preventDefault();
    e.stopPropagation();
    this.dragging = false;
  }

  handleDrop(e) {
    e.preventDefault();
    e.stopPropagation();
    this.dragging = false;

    const droppedFiles = [...e.dataTransfer.files];
    this.addFiles(droppedFiles);
  }

  // Trigger file input click
  openFileBrowser() {
    const fileInput = this.querySelector('#file-input');
    if (fileInput) {
      fileInput.click();
    }
  }

  // Handle file input change
  handleFileInputChange(e) {
    const selectedFiles = [...e.target.files];
    this.addFiles(selectedFiles);
    // Reset input so same file can be selected again
    e.target.value = '';
  }

  // Add files to the list
  addFiles(newFiles) {
    this.invalidFiles = [];

    // Filter for Excel files
    const validFiles = [];

    for (const file of newFiles) {
      if (this.isValidExcelFile(file)) {
        validFiles.push({
          id: Math.random().toString(36).substr(2, 9),
          file,
          name: file.name,
          size: file.size,
          type: file.type
        });
      } else {
        this.invalidFiles.push(file.name);
      }
    }

    this.files = [...this.files, ...validFiles];

    // Show alert if there were invalid files
    if (this.invalidFiles.length > 0) {
      setTimeout(() => {
        this.invalidFiles = [];
      }, 5000);
    }
  }

  // Remove a file from the list
  removeFile(fileId) {
    this.files = this.files.filter(file => file.id !== fileId);
  }

  // Clear all files
  clearFiles() {
    this.files = [];
    this.uploadComplete = false;
    this.uploadError = null;
  }

  // Handle upload button click
  async handleUpload() {
    if (this.files.length === 0 || this.uploading) return;

    this.uploading = true;
    this.uploadProgress = 0;
    this.uploadError = null;

    try {
      // Create form data
      const formData = new FormData();
      this.files.forEach(fileObj => {
        formData.append('files', fileObj.file);
      });

      // Simulate progress updates
      const interval = setInterval(() => {
        if (this.uploadProgress < 95) {
          this.uploadProgress += Math.floor(Math.random() * 10);
          if (this.uploadProgress > 95) this.uploadProgress = 95;
        }
      }, 300);

      // Upload files
      const response = await uploadFiles(formData);

      // Upload complete
      clearInterval(interval);
      this.uploadProgress = 100;
      this.uploadComplete = true;

      // Clear files after a delay
      setTimeout(() => {
        this.clearFiles();
        this.uploading = false;
      }, 3000);

    } catch (error) {
      console.error('Upload error:', error);
      this.uploadError = error.message || 'Failed to upload files';
      this.uploading = false;
    }
  }

  render() {
    return html`
      <div class="file-upload-container">
        ${this.invalidFiles.length > 0 ? html`
          <div class="invalid-files-alert">
            <i class="fas fa-exclamation-triangle"></i>
            <div>
              <strong>Invalid file(s):</strong> Only Excel files (.xlsx) are allowed.
              <ul>
                ${this.invalidFiles.map(filename => html`<li>${filename}</li>`)}
              </ul>
            </div>
            <button class="close-alert" @click=${() => this.invalidFiles = []}>
              <i class="fas fa-times"></i>
            </button>
          </div>
        ` : ''}
        
        ${this.uploading ? html`
          <div class="upload-progress-container">
            <h3>${this.uploadComplete ? 'Upload Complete!' : 'Uploading Files...'}</h3>
            <div class="progress-bar">
              <div class="progress-bar-inner" style="width: ${this.uploadProgress}%"></div>
            </div>
            <div class="progress-text">${this.uploadProgress}%</div>
            ${this.uploadError ? html`<div class="upload-error">${this.uploadError}</div>` : ''}
          </div>
        ` : html`
          ${this.files.length === 0 ? html`
            <div class="drop-zone ${this.dragging ? 'dragging' : ''}"
                 @dragenter=${this.handleDragEnter}
                 @dragover=${this.handleDragOver}
                 @dragleave=${this.handleDragLeave}
                 @drop=${this.handleDrop}
                 @click=${() => this.openFileBrowser()}>
              <input type="file" id="file-input" multiple accept=".xlsx" 
                     @change=${this.handleFileInputChange} style="display: none;">
              <div class="drop-zone-content">
                <i class="fas fa-cloud-upload-alt"></i>
                <h3>Drag & Drop Excel Files Here</h3>
                <p>Only .xlsx files are supported</p>
                <button class="browse-btn">Browse Files</button>
              </div>
            </div>
          ` : html`
            <div class="selected-files">
              <div class="files-header">
                <h3>Selected Files (${this.files.length})</h3>
                <button class="clear-btn" @click=${this.clearFiles}>
                  <i class="fas fa-times"></i> Clear All
                </button>
              </div>
              
              <div class="files-list">
                ${this.files.map(file => html`
                  <div class="file-item">
                    <div class="file-icon">
                      <i class="fas fa-file-excel"></i>
                    </div>
                    <div class="file-details">
                      <div class="file-name">${file.name}</div>
                      <div class="file-size">${formatFileSize(file.size)}</div>
                    </div>
                    <button class="remove-file-btn" @click=${() => this.removeFile(file.id)}>
                      <i class="fas fa-times"></i>
                    </button>
                  </div>
                `)}
              </div>
              
              <div class="upload-actions">
                <button class="add-more-btn" @click=${() => this.openFileBrowser()}>
                  <i class="fas fa-plus"></i> Add More Files
                </button>
                <button class="upload-btn" @click=${this.handleUpload}>
                  <i class="fas fa-upload"></i> Upload Files
                </button>
                <input type="file" id="file-input" multiple accept=".xlsx" 
                       @change=${this.handleFileInputChange} style="display: none;">
              </div>
            </div>
          `}
        `}
      </div>

      <style>
        .file-upload-container {
          margin: 2rem 0;
        }
        
        .invalid-files-alert {
          background-color: rgba(207, 102, 121, 0.1);
          border-left: 4px solid var(--error);
          padding: 1rem;
          margin-bottom: 1rem;
          border-radius: 4px;
          display: flex;
          align-items: flex-start;
          gap: 1rem;
        }
        
        .invalid-files-alert i {
          color: var(--error);
          font-size: 1.25rem;
        }
        
        .invalid-files-alert ul {
          margin: 0.5rem 0 0 1.5rem;
          padding: 0;
        }
        
        .invalid-files-alert li {
          margin-bottom: 0.25rem;
        }
        
        .close-alert {
          background: transparent;
          border: none;
          color: var(--text-secondary);
          cursor: pointer;
          padding: 0;
          margin-left: auto;
        }
        
        .close-alert:hover {
          color: var(--text-primary);
        }
        
        .drop-zone {
          border: 2px dashed var(--text-secondary);
          border-radius: 8px;
          padding: 3rem 2rem;
          text-align: center;
          cursor: pointer;
          transition: all 0.2s;
        }
        
        .drop-zone.dragging {
          border-color: var(--accent);
          background-color: rgba(187, 134, 252, 0.05);
        }
        
        .drop-zone-content {
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 1rem;
        }
        
        .drop-zone-content i {
          font-size: 4rem;
          color: var(--text-secondary);
        }
        
        .drop-zone-content h3 {
          margin: 0;
        }
        
        .drop-zone-content p {
          margin: 0;
          color: var(--text-secondary);
        }
        
        .browse-btn {
          background-color: var(--accent);
          color: var(--bg-primary);
          padding: 0.75rem 1.5rem;
          border-radius: 4px;
          border: none;
          cursor: pointer;
          font-weight: 500;
          transition: all 0.2s;
        }
        
        .browse-btn:hover {
          opacity: 0.9;
        }
        
        .selected-files {
          background-color: var(--card-bg);
          border-radius: 8px;
          padding: 1.5rem;
        }
        
        .files-header {
          display: flex;
          justify-content: space-between;
          align-items: center;
          margin-bottom: 1rem;
          padding-bottom: 1rem;
          border-bottom: 1px solid var(--bg-secondary);
        }
        
        .files-header h3 {
          margin: 0;
        }
        
        .clear-btn {
          background-color: transparent;
          color: var(--text-secondary);
          border: none;
          cursor: pointer;
          padding: 0.5rem;
          display: flex;
          align-items: center;
          gap: 0.5rem;
        }
        
        .clear-btn:hover {
          color: var(--error);
        }
        
        .files-list {
          max-height: 300px;
          overflow-y: auto;
          margin-bottom: 1.5rem;
        }
        
        .files-list .file-item {
          display: flex;
          align-items: center;
          padding: 0.75rem;
          border-radius: 4px;
          background-color: var(--bg-secondary);
          margin-bottom: 0.5rem;
        }
        
        .files-list .file-icon {
          font-size: 1.25rem;
          margin-right: 1rem;
          color: #4CAF50;  /* Excel green color */
        }
        
        .files-list .file-details {
          flex: 1;
        }
        
        .files-list .file-name {
          font-weight: 500;
          margin-bottom: 0.25rem;
          white-space: nowrap;
          overflow: hidden;
          text-overflow: ellipsis;
          max-width: 400px;
        }
        
        .files-list .file-size {
          font-size: 0.85rem;
          color: var(--text-secondary);
        }
        
        .remove-file-btn {
          background-color: transparent;
          color: var(--text-secondary);
          border: none;
          cursor: pointer;
          width: 30px;
          height: 30px;
          display: flex;
          align-items: center;
          justify-content: center;
          border-radius: 50%;
        }
        
        .remove-file-btn:hover {
          color: var(--error);
          background-color: rgba(207, 102, 121, 0.1);
        }
        
        .upload-actions {
          display: flex;
          gap: 1rem;
        }
        
        .add-more-btn {
          background-color: var(--bg-secondary);
          color: var(--text-primary);
          padding: 0.75rem 1.5rem;
          border-radius: 4px;
          border: none;
          cursor: pointer;
          font-weight: 500;
          display: flex;
          align-items: center;
          gap: 0.5rem;
        }
        
        .upload-btn {
          background-color: var(--accent);
          color: var(--bg-primary);
          padding: 0.75rem 1.5rem;
          border-radius: 4px;
          border: none;
          cursor: pointer;
          font-weight: 500;
          flex: 1;
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 0.5rem;
        }
        
        .upload-btn:hover {
          opacity: 0.9;
        }
        
        .upload-progress-container {
          padding: 2rem;
          background-color: var(--card-bg);
          border-radius: 8px;
          text-align: center;
        }
        
        .progress-bar {
          height: 10px;
          background-color: var(--bg-secondary);
          border-radius: 5px;
          margin: 1.5rem 0 0.5rem;
          overflow: hidden;
        }
        
        .progress-bar-inner {
          height: 100%;
          background-color: var(--accent);
          border-radius: 5px;
          transition: width 0.3s ease;
        }
        
        .progress-text {
          font-weight: 500;
          color: var(--accent);
          margin-bottom: 1rem;
        }
        
        .upload-error {
          color: var(--error);
          margin-top: 1rem;
          padding: 0.75rem;
          background-color: rgba(207, 102, 121, 0.1);
          border-radius: 4px;
        }
        
        @media (max-width: 768px) {
          .upload-actions {
            flex-direction: column;
          }
          
          .files-list .file-name {
            max-width: 200px;
          }
        }
      </style>
    `;
  }
}

customElements.define('file-upload', FileUpload);