import { LitElement, html } from 'https://esm.run/lit';
import { initWebSocket, addEventListener, EVENT_TYPES } from '../utils/websocket_utils.js';
import { retryFile, deleteFile } from '../utils/api_utils.js';
import { formatFileSize, formatDate, getStatusClass, getStatusIcon } from '../utils/file_utils.js';

class FileList extends LitElement {
  static get properties() {
    return {
      files: { type: Array },
      loading: { type: Boolean },
      activeFilter: { type: String },
      confirmingDeleteHash: { type: String }
    };
  }

  constructor() {
    super();
    this.files = [];
    this.loading = true;
    this.activeFilter = 'all';
    this.confirmingDeleteHash = null;
  }

  // Disable Shadow DOM to access global styles
  createRenderRoot() {
    return this;
  }

  connectedCallback() {
    super.connectedCallback();
    initWebSocket();

    // Listen for file list updates
    addEventListener(EVENT_TYPES.FILES_LIST, (data) => {
      this.files = data.files || [];
      this.loading = false;
    });

    // Listen for individual file updates
    addEventListener(EVENT_TYPES.STATUS_UPDATE, (data) => {
      const index = this.files.findIndex(file => file.hash === data.hash);
      if (index >= 0) {
        const newFiles = [...this.files];
        newFiles[index] = data;
        this.files = newFiles;
      }
    });

    // Listen for file deletions
    addEventListener(EVENT_TYPES.FILE_DELETED, (data) => {
      if (data.hash) {
        this.files = this.files.filter(file => file.hash !== data.hash);
      }
    });

    // Initial data load
    addEventListener(EVENT_TYPES.INITIAL_DATA, (data) => {
      this.files = data.files || [];
      this.loading = false;
    });
  }

  // Helper method to sort files by date (newest first)
  sortFilesByDate(files) {
    return [...files].sort((a, b) => {
      const dateA = new Date(a.created_at);
      const dateB = new Date(b.created_at);
      return dateB - dateA; // Descending order (newest first)
    });
  }

  // Filter files based on active filter and sort by date
  get filteredFiles() {
    let result = this.activeFilter === 'all'
      ? this.files
      : this.files.filter(file => file.status.toLowerCase() === this.activeFilter.toLowerCase());

    // Sort by date (newest first)
    return this.sortFilesByDate(result);
  }

  // Handle filter change
  handleFilterChange(filter) {
    this.activeFilter = filter;
  }

  // Retry a failed file
  async handleRetry(fileHash, event) {
    event.preventDefault();
    event.stopPropagation();

    try {
      await retryFile(fileHash);
      // The websocket will update the UI
    } catch (error) {
      console.error('Error retrying file:', error);
      alert('Failed to retry file: ' + error.message);
    }
  }

  // Delete a file
  async handleDelete(fileHash, event) {
    event.preventDefault();
    event.stopPropagation();

    if (this.confirmingDeleteHash === fileHash) {
      try {
        await deleteFile(fileHash);
        this.confirmingDeleteHash = null;
        // The websocket will update the UI
      } catch (error) {
        console.error('Error deleting file:', error);
        alert('Failed to delete file: ' + error.message);
      }
    } else {
      this.confirmingDeleteHash = fileHash;

      // Clear confirmation after 5 seconds
      setTimeout(() => {
        if (this.confirmingDeleteHash === fileHash) {
          this.confirmingDeleteHash = null;
        }
      }, 5000);
    }
  }

  render() {
    if (this.loading) {
      return html`
        <div class="loading-container">
          <i class="fas fa-spinner fa-spin"></i>
          <p>Loading files...</p>
        </div>
      `;
    }

    return html`
      <div class="file-list-container">
        <div class="filter-tabs">
          <button class="filter-tab ${this.activeFilter === 'all' ? 'active' : ''}"
                  @click=${() => this.handleFilterChange('all')}>
            <i class="fas fa-list"></i> All Files
          </button>
          <button class="filter-tab ${this.activeFilter === 'pending' ? 'active' : ''}"
                  @click=${() => this.handleFilterChange('pending')}>
            <i class="fas fa-clock"></i> Pending
          </button>
          <button class="filter-tab ${this.activeFilter === 'processing' ? 'active' : ''}"
                  @click=${() => this.handleFilterChange('processing')}>
            <i class="fas fa-spinner"></i> Processing
          </button>
          <button class="filter-tab ${this.activeFilter === 'processed' ? 'active' : ''}"
                  @click=${() => this.handleFilterChange('processed')}>
            <i class="fas fa-check-circle"></i> Processed
          </button>
          <button class="filter-tab ${this.activeFilter === 'failed' ? 'active' : ''}"
                  @click=${() => this.handleFilterChange('failed')}>
            <i class="fas fa-exclamation-circle"></i> Failed
          </button>
        </div>
        
        ${this.filteredFiles.length === 0 ?
        html`
            <div class="empty-state">
              <i class="fas fa-folder-open"></i>
              <p>No ${this.activeFilter !== 'all' ? this.activeFilter : ''} files found</p>
            </div>
          ` :
        html`
            <div class="file-list">
              ${this.filteredFiles.map(file => html`
                <div class="file-item ${getStatusClass(file.status)}">
                  <div class="file-icon">
                    <i class="fas fa-file-alt"></i>
                  </div>
                  <div class="file-details">
                    <div class="file-name">${file.file_name}</div>
                    <div class="file-meta">
                      <span class="file-size">${formatFileSize(file.size)}</span>
                      <span class="file-date">Uploaded: ${formatDate(file.created_at)}</span>
                    </div>
                    ${file.error ? html`<div class="file-error">Error: ${file.error}</div>` : ''}
                  </div>
                  <div class="file-status">
                    <span class="status-badge">
                      <i class="fas ${getStatusIcon(file.status)}"></i>
                      ${file.status}
                    </span>
                    ${file.status === 'Failed' ?
            html`
                        <div class="file-actions">
                          <button class="action-btn retry-btn" @click=${(e) => this.handleRetry(file.hash, e)}>
                            <i class="fas fa-redo"></i> Retry
                          </button>
                          <button class="action-btn delete-btn ${this.confirmingDeleteHash === file.hash ? 'confirming' : ''}" 
                                 @click=${(e) => this.handleDelete(file.hash, e)}>
                            ${this.confirmingDeleteHash === file.hash ?
                html`<i class="fas fa-check"></i> Confirm` :
                html`<i class="fas fa-trash"></i> Delete`}
                          </button>
                        </div>
                      ` : ''}
                  </div>
                </div>
              `)}
            </div>
          `
      }
      </div>

      <style>
        .file-list-container {
          margin: 2rem 0;
        }
        
        .filter-tabs {
          display: flex;
          flex-wrap: wrap;
          gap: 0.5rem;
          margin-bottom: 1.5rem;
        }
        
        .filter-tab {
          background-color: var(--bg-secondary);
          color: var(--text-secondary);
          border: none;
          padding: 0.5rem 1rem;
          border-radius: 4px;
          cursor: pointer;
          font-weight: 500;
          transition: all 0.2s;
          display: flex;
          align-items: center;
          gap: 0.5rem;
        }
        
        .filter-tab.active {
          background-color: var(--accent);
          color: var(--bg-primary);
        }
        
        .file-list {
          display: flex;
          flex-direction: column;
          gap: 1rem;
        }
        
        .file-item {
          background-color: var(--card-bg);
          border-radius: 8px;
          padding: 1rem;
          display: flex;
          align-items: center;
          gap: 1rem;
          transition: all 0.2s;
        }
        
        .file-icon {
          font-size: 1.5rem;
          color: var(--text-secondary);
          width: 40px;
          text-align: center;
        }
        
        .file-details {
          flex: 1;
        }
        
        .file-name {
          font-weight: 500;
          margin-bottom: 0.25rem;
        }
        
        .file-meta {
          display: flex;
          gap: 1rem;
          font-size: 0.85rem;
          color: var(--text-secondary);
        }
        
        .file-error {
          margin-top: 0.5rem;
          color: var(--error);
          font-size: 0.9rem;
        }
        
        .file-status {
          display: flex;
          flex-direction: column;
          align-items: flex-end;
          gap: 0.5rem;
        }
        
        .status-badge {
          padding: 0.35rem 0.75rem;
          border-radius: 50px;
          font-size: 0.85rem;
          font-weight: 500;
          display: flex;
          align-items: center;
          gap: 0.5rem;
        }
        
        .status-pending .status-badge {
          background-color: rgba(255, 183, 77, 0.2);
          color: #ffb74d;
        }
        
        .status-processing .status-badge {
          background-color: rgba(187, 134, 252, 0.2);
          color: #bb86fc;
        }
        
        .status-success .status-badge {
          background-color: rgba(3, 218, 198, 0.2);
          color: #03dac6;
        }
        
        .status-error .status-badge {
          background-color: rgba(207, 102, 121, 0.2);
          color: #cf6679;
        }
        
        .file-actions {
          display: flex;
          gap: 0.5rem;
        }
        
        .action-btn {
          padding: 0.35rem 0.75rem;
          border-radius: 4px;
          font-size: 0.85rem;
          font-weight: 500;
          background-color: var(--bg-secondary);
          color: var(--text-primary);
          border: none;
          cursor: pointer;
          display: flex;
          align-items: center;
          gap: 0.5rem;
          transition: all 0.2s;
        }
        
        .retry-btn:hover {
          background-color: var(--accent);
          color: var(--bg-primary);
        }
        
        .delete-btn:hover {
          background-color: var(--error);
          color: var(--bg-primary);
        }
        
        .delete-btn.confirming {
          background-color: var(--error);
          color: var(--bg-primary);
        }
        
        .loading-container, .empty-state {
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: center;
          padding: 3rem 0;
          color: var(--text-secondary);
        }
        
        .loading-container i, .empty-state i {
          font-size: 2rem;
          margin-bottom: 1rem;
        }
        
        @media (max-width: 768px) {
          .file-item {
            flex-direction: column;
            align-items: flex-start;
          }
          
          .file-status {
            width: 100%;
            flex-direction: row;
            justify-content: space-between;
            margin-top: 1rem;
          }
        }
      </style>
    `;
  }
}

customElements.define('file-list', FileList);