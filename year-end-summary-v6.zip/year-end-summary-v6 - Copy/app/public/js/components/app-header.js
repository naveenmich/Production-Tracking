import { LitElement, html } from 'https://esm.run/lit';

class AppHeader extends LitElement {
  static get properties() {
    return {
      currentPage: { type: String, attribute: 'current-page' }
    };
  }

  constructor() {
    super();
    this.currentPage = 'home';
  }

  // Disable Shadow DOM to access global styles
  createRenderRoot() {
    return this;
  }

  render() {
    return html`
      <header class="app-header">
          <div class="container">
              <div class="app-header-content">
                  <div class="app-logo">
                      <i class="fas fa-chart-line"></i>
                      <span>Michelin ETD Year End Summary</span>
                  </div>
                  <nav class="app-nav">
                      <a href="/" class="${this.currentPage === 'home' ? 'active' : ''}">
                          <i class="fas fa-home"></i> Dashboard
                      </a>
                      <a href="/upload" class="${this.currentPage === 'upload' ? 'active' : ''}">
                          <i class="fas fa-upload"></i> Upload Files
                      </a>
                      <a href="/data-browser" class="${this.currentPage === 'data-browser' ? 'active' : ''}">
                          <i class="fas fa-database"></i> Data Files
                      </a>
                  </nav>
              </div>
          </div>
      </header>

      <style>
        .app-header {
          background-color: var(--bg-secondary);
          box-shadow: 0 2px 4px rgba(0, 0, 0, 0.3);
          padding: 1rem 0;
        }
        
        .app-header-content {
          display: flex;
          justify-content: space-between;
          align-items: center;
        }
        
        .app-logo {
          display: flex;
          align-items: center;
          font-size: 1.25rem;
          font-weight: 600;
        }
        
        .app-logo i {
          color: var(--accent);
          margin-right: 0.75rem;
          font-size: 1.5rem;
        }
        
        .app-nav {
          display: flex;
          gap: 1.5rem;
        }
        
        .app-nav a {
          color: var(--text-secondary);
          text-decoration: none;
          display: flex;
          align-items: center;
          gap: 0.5rem;
          padding: 0.5rem 0;
          transition: color 0.2s;
        }
        
        .app-nav a:hover, .app-nav a.active {
          color: var(--accent);
        }
        
        .app-nav a i {
          font-size: 1rem;
        }
        
        @media (max-width: 768px) {
          .app-header-content {
            flex-direction: column;
            gap: 1rem;
          }
          
          .app-nav {
            width: 100%;
            justify-content: space-around;
          }
        }
      </style>
    `;
  }
}

customElements.define('app-header', AppHeader);