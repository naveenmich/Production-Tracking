import { LitElement, html } from 'https://esm.run/lit';
import { initWebSocket, addEventListener, EVENT_TYPES } from '../utils/websocket_utils.js';

class StatusCard extends LitElement {
    static get properties() {
        return {
            type: { type: String },
            count: { type: Number },
            loading: { type: Boolean }
        };
    }

    constructor() {
        super();
        this.type = 'pending';
        this.count = 0;
        this.loading = true;
        this.iconMap = {
            pending: 'fa-clock',
            processing: 'fa-spinner',
            processed: 'fa-check-circle',
            failed: 'fa-exclamation-circle'
        };
        this.colorMap = {
            pending: '#ffb74d',
            processing: '#bb86fc',
            processed: '#03dac6',
            failed: '#cf6679'
        };
        this.titleMap = {
            pending: 'Pending Files',
            processing: 'Processing Files',
            processed: 'Processed Files',
            failed: 'Failed Files'
        };
    }

    // Disable Shadow DOM to access global styles
    createRenderRoot() {
        return this;
    }

    connectedCallback() {
        super.connectedCallback();
        initWebSocket();

        // Update counts when stats are updated
        this.statsListener = (data) => {
            this.count = data[this.type.toLowerCase()] || 0;
            this.loading = false;
        };

        addEventListener(EVENT_TYPES.STATS_UPDATE, this.statsListener);
        addEventListener(EVENT_TYPES.INITIAL_DATA, (data) => {
            this.count = data.counts[this.type.toLowerCase()] || 0;
            this.loading = false;
        });
    }

    disconnectedCallback() {
        super.disconnectedCallback();
        // Clean up event listeners
        removeEventListener(EVENT_TYPES.STATS_UPDATE, this.statsListener);
        removeEventListener(EVENT_TYPES.INITIAL_DATA, this.statsListener);
    }

    render() {
        return html`
      <div class="status-card ${this.type.toLowerCase()}-card">
        <div class="card-icon">
          <i class="fas ${this.iconMap[this.type.toLowerCase()]}"></i>
        </div>
        <div class="card-content">
          <h3>${this.titleMap[this.type.toLowerCase()]}</h3>
          <div class="card-count">${this.loading ?
                html`<i class="fas fa-spinner fa-spin"></i>` :
                this.count}</div>
        </div>
      </div>

      <style>
        .status-card {
          background-color: var(--card-bg);
          border-radius: 8px;
          padding: 1.5rem;
          display: flex;
          align-items: center;
          gap: 1.25rem;
          box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
          margin-bottom: 1rem;
        }
        
        .card-icon {
          font-size: 2rem;
          width: 60px;
          height: 60px;
          display: flex;
          align-items: center;
          justify-content: center;
          border-radius: 50%;
          color: var(--bg-primary);
        }
        
        .card-content {
          flex: 1;
        }
        
        .card-content h3 {
          font-size: 1rem;
          font-weight: 500;
          margin: 0 0 0.5rem 0;
          color: var(--text-secondary);
        }
        
        .card-count {
          font-size: 1.75rem;
          font-weight: 700;
          color: var(--text-primary);
        }
        
        .pending-card .card-icon {
          background-color: ${this.colorMap.pending};
        }
        
        .processing-card .card-icon {
          background-color: ${this.colorMap.processing};
        }
        
        .processed-card .card-icon {
          background-color: ${this.colorMap.processed};
        }
        
        .failed-card .card-icon {
          background-color: ${this.colorMap.failed};
        }
        
        .status-cards {
          display: grid;
          grid-template-columns: repeat(4, 1fr);
          gap: 1rem;
          margin: 1.5rem 0;
        }
        
        @media (max-width: 992px) {
          .status-cards {
            grid-template-columns: repeat(2, 1fr);
          }
        }
        
        @media (max-width: 576px) {
          .status-cards {
            grid-template-columns: 1fr;
          }
        }
      </style>
    `;
    }
}

customElements.define('status-card', StatusCard);