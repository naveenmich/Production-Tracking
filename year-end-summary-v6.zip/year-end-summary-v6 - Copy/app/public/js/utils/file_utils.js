/**
 * File utility functions
 */

// Format file size in human-readable format
export function formatFileSize(bytes) {
    if (bytes === 0) return '0 Bytes';

    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));

    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

// Format date in readable format
export function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleString();
}

// Get appropriate status class
export function getStatusClass(status) {
    switch (status.toLowerCase()) {
        case 'pending':
            return 'status-pending';
        case 'processing':
            return 'status-processing';
        case 'processed':
            return 'status-success';
        case 'failed':
            return 'status-error';
        default:
            return '';
    }
}

// Get appropriate status icon
export function getStatusIcon(status) {
    switch (status.toLowerCase()) {
        case 'pending':
            return 'fa-clock';
        case 'processing':
            return 'fa-spinner fa-spin';
        case 'processed':
            return 'fa-check-circle';
        case 'failed':
            return 'fa-exclamation-circle';
        default:
            return 'fa-question-circle';
    }
}