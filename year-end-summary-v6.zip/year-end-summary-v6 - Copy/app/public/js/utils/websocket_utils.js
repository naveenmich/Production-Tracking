/**
 * WebSocket utility functions for real-time connections
 */

// Singleton connection
let wsConnection = null;
let reconnectAttempts = 0;
const MAX_RECONNECT_ATTEMPTS = 5;
const RECONNECT_DELAY = 2000; // 2 seconds
const eventListeners = {};
let isConnecting = false;

// Store different types of events
const EVENT_TYPES = {
    STATUS_UPDATE: 'status_update',
    FILES_LIST: 'files_list',
    FILE_DELETED: 'file_deleted',
    STATS_UPDATE: 'stats_update',
    INITIAL_DATA: 'initial_data'
};

/**
 * Initialize WebSocket connection
 * @returns {Promise<WebSocket>} The WebSocket connection
 */
export function initWebSocket() {
    if (wsConnection && wsConnection.readyState === WebSocket.OPEN) {
        return Promise.resolve(wsConnection);
    }

    if (isConnecting) {
        // If already connecting, wait for it to finish
        return new Promise((resolve, reject) => {
            const checkInterval = setInterval(() => {
                if (wsConnection && wsConnection.readyState === WebSocket.OPEN) {
                    clearInterval(checkInterval);
                    resolve(wsConnection);
                } else if (!isConnecting) {
                    clearInterval(checkInterval);
                    reject(new Error('WebSocket connection failed'));
                }
            }, 100);
        });
    }

    isConnecting = true;

    return new Promise((resolve, reject) => {
        const wsUrl = `${window.location.protocol === 'https:' ? 'wss:' : 'ws:'}//${window.location.host}/ws`;
        wsConnection = new WebSocket(wsUrl);

        wsConnection.onopen = () => {
            console.log('WebSocket connection established');
            reconnectAttempts = 0;
            isConnecting = false;
            resolve(wsConnection);
        };

        wsConnection.onmessage = (event) => {
            try {
                const data = JSON.parse(event.data);
                console.log('WebSocket message received:', data.type);

                // Dispatch event to registered listeners
                if (data.type && eventListeners[data.type]) {
                    eventListeners[data.type].forEach(listener => {
                        try {
                            listener(data.data);
                        } catch (error) {
                            console.error(`Error in event listener for ${data.type}:`, error);
                        }
                    });
                }

                // Special handling for initial_data
                if (data.type === 'initial_data') {
                    // Also trigger FILES_LIST and STATS_UPDATE events from the same data
                    if (eventListeners[EVENT_TYPES.FILES_LIST] && data.data.files) {
                        eventListeners[EVENT_TYPES.FILES_LIST].forEach(listener => {
                            try {
                                listener(data.data);
                            } catch (error) {
                                console.error(`Error in event listener for ${EVENT_TYPES.FILES_LIST}:`, error);
                            }
                        });
                    }

                    if (eventListeners[EVENT_TYPES.STATS_UPDATE] && data.data.counts) {
                        eventListeners[EVENT_TYPES.STATS_UPDATE].forEach(listener => {
                            try {
                                listener(data.data.counts);
                            } catch (error) {
                                console.error(`Error in event listener for ${EVENT_TYPES.STATS_UPDATE}:`, error);
                            }
                        });
                    }
                }
            } catch (error) {
                console.error('Error parsing WebSocket message:', error);
            }
        };

        wsConnection.onclose = () => {
            console.log('WebSocket connection closed');
            wsConnection = null;
            isConnecting = false;

            // Attempt to reconnect
            if (reconnectAttempts < MAX_RECONNECT_ATTEMPTS) {
                reconnectAttempts++;
                setTimeout(() => {
                    console.log(`Attempting to reconnect (${reconnectAttempts}/${MAX_RECONNECT_ATTEMPTS})...`);
                    initWebSocket().catch(error => {
                        console.error('Reconnection failed:', error);
                    });
                }, RECONNECT_DELAY * reconnectAttempts);
            }
        };

        wsConnection.onerror = (error) => {
            console.error('WebSocket error:', error);
            isConnecting = false;
            reject(error);
        };
    });
}

/**
 * Register a listener for specific event type
 * @param {string} eventType - Type of event to listen for
 * @param {function} callback - Function to call when event is received
 */
export function addEventListener(eventType, callback) {
    if (!eventListeners[eventType]) {
        eventListeners[eventType] = [];
    }
    eventListeners[eventType].push(callback);

    // Initialize WebSocket connection if not already
    initWebSocket().catch(error => {
        console.error('Failed to initialize WebSocket:', error);
    });
}

/**
 * Remove a listener for specific event type
 * @param {string} eventType - Type of event
 * @param {function} callback - Function to remove
 */
export function removeEventListener(eventType, callback) {
    if (eventListeners[eventType]) {
        eventListeners[eventType] = eventListeners[eventType].filter(
            listener => listener !== callback
        );
    }
}

// Export event types
export { EVENT_TYPES };