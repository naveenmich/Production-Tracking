/**
 * API utility functions for making requests to the backend
 */

// Fetch JSON data from API
export async function fetchJson(url, options = {}) {
    const headers = {
        'Content-Type': 'application/json',
        ...options.headers
    };

    const response = await fetch(url, {
        ...options,
        headers
    });

    if (!response.ok) {
        const error = await response.json().catch(() => ({
            detail: `HTTP error ${response.status}`
        }));
        throw new Error(error.detail || 'API request failed');
    }

    return response.json();
}

// Post data to API
export async function postJson(url, data, options = {}) {
    return fetchJson(url, {
        method: 'POST',
        body: JSON.stringify(data),
        ...options
    });
}

// Helper to get all files
export async function getFiles() {
    return fetchJson('/api/files');
}

// Helper to upload files
export async function uploadFiles(formData) {
    const response = await fetch('/api/upload', {
        method: 'POST',
        body: formData
    });

    if (!response.ok) {
        const error = await response.json().catch(() => ({
            detail: `HTTP error ${response.status}`
        }));
        throw new Error(error.detail || 'Upload failed');
    }

    return response.json();
}

// Helper to retry a failed file
export async function retryFile(fileHash) {
    return fetchJson(`/api/retry/${fileHash}`, {
        method: 'POST'
    });
}

// Helper to delete a file
export async function deleteFile(fileHash) {
    return fetchJson(`/api/clean/${fileHash}`, {
        method: 'DELETE'
    });
}