from sqlalchemy import Column, String, Integer, DateTime, func
from app.database import Base
import datetime

# Create a function to return current time in local timezone


def local_now():
    return datetime.datetime.now()


class File(Base):
    __tablename__ = "files"

    hash = Column(String, primary_key=True)
    file_path = Column(String, index=True)
    file_name = Column(String)
    size = Column(Integer)
    # Pending, Processing, Processed, Failed
    status = Column(String, default="Pending")
    error = Column(String, nullable=True)
    created_at = Column(DateTime, default=local_now)
    updated_at = Column(DateTime, default=local_now, onupdate=local_now)

    def to_dict(self):
        return {
            "hash": self.hash,
            "file_name": self.file_name,
            "file_path": self.file_path,
            "size": self.size,
            "status": self.status,
            "error": self.error,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None
        }
