from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from pathlib import Path
import asyncio
import os
from contextlib import asynccontextmanager

# Import routers
from app.routes.web import router as web_router
from app.routes.ws import router as ws_router
from app.routes.api.file_api import ensure_worker_running, router as file_api_router, stop_workers

# Import database functions
from app.database import init_db

# Define lifespan context manager for startup/shutdown events


@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup: Initialize database
    print("Starting up application...")
    init_db()
    ensure_worker_running()

    # Create uploads directory if it doesn't exist
    UPLOAD_DIR = Path(__file__).parent / "uploads"
    UPLOAD_DIR.mkdir(exist_ok=True)

    # Yield control back to FastAPI
    yield

    # Shutdown: Stop worker threads
    print("Shutting down application...")
    stop_workers()

# Create FastAPI app with lifespan
app = FastAPI(
    title="Michelin ETD Year End Summary",
    version="1.0.0",
    lifespan=lifespan
)

# Configure static files
app.mount("/static", StaticFiles(directory=Path(__file__).parent /
          "public"), name="static")

# Configure data-warehouse files as publicly accessible
data_warehouse_path = Path(__file__).parent.parent / "data-warehouse"
app.mount("/data", StaticFiles(directory=data_warehouse_path,
          html=True), name="data")

# Configure templates
templates = Jinja2Templates(directory=Path(__file__).parent / "templates")

# Include routers
app.include_router(web_router)
app.include_router(ws_router)
app.include_router(file_api_router)

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("app.main:app", host="0.0.0.0", port=8000, reload=True)
