from pydantic import BaseModel
from typing import Optional, List
from datetime import datetime


class FileBase(BaseModel):
    hash: str
    file_name: str
    file_path: str
    size: int
    status: str = "Pending"
    error: Optional[str] = None


class FileCreate(FileBase):
    pass


class FileResponse(FileBase):
    created_at: datetime
    updated_at: datetime

    class Config:
        # Change orm_mode to from_attributes for Pydantic v2
        from_attributes = True  # This was previously orm_mode = True


class FilesList(BaseModel):
    files: List[FileResponse]
    counts: dict
