from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, Session
from database.models import Base, User, Admin, UserRole

# Database configuration
SQLALCHEMY_DATABASE_URL = "sqlite:///./production.db"
engine = create_engine(
    SQLALCHEMY_DATABASE_URL,
    connect_args={"check_same_thread": False}
)

# Create session factory
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)


def get_db():
    """Dependency for getting database session"""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def create_admin_user(db: Session):
    """Create admin user if it doesn't exist"""
    try:
        admin = db.query(User).filter(User.sap_id == "0000").first()

        if not admin:
            admin_user = User(
                sap_id="0000",
                name="admin",
                password="123456",
                role=UserRole.ADMIN
            )
            db.add(admin_user)

            admin_role = Admin(user_id="0000")
            db.add(admin_role)

            db.commit()
            print("Admin user created successfully")
        else:
            print("Admin user already exists")
    except Exception as e:
        db.rollback()
        print(f"Error creating admin user: {e}")


def init_db():
    """Initialize database, create tables and admin user"""
    try:
        # Create tables
        Base.metadata.create_all(bind=engine)

        # Create admin user
        db = SessionLocal()
        try:
            create_admin_user(db)
        finally:
            db.close()

    except Exception as e:
        print(f"Error initializing database: {e}")
        raise e  # Re-raise to see the full error stack
