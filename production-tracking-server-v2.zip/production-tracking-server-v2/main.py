from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from database.service import init_db
from routes.auth.route import router as auth_router
from routes.plant.route import router as plant_router
from routes.zone.route import router as zone_router
from routes.loop.route import router as loop_router
from routes.line.route import router as line_router
from routes.cell.route import router as cell_router
from routes.plant_admin.route import router as plant_admin_router
from routes.planner.route import router as planner_router
from routes.team_leader.route import router as team_leader_router
from routes.member.route import router as member_router
from routes.shift.route import router as shift_router
from routes.plan.route import router as plan_router
from routes.production.route import router as production_router
from routes.loss_reason.route import router as loss_reason_router
from routes.loss.route import router as loss_router


# Initialize database
init_db()

# Create FastAPI app
app = FastAPI(
    title="Production Management API",
    description="API for managing production data",
    version="1.0.0"
)

# Configure CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # In production, replace with actual frontend domain
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include routers
app.include_router(auth_router, prefix="/api/auth", tags=["Authentication"])
app.include_router(plant_router, prefix="/api/plants", tags=["Plants"])
app.include_router(zone_router, prefix="/api/zones", tags=["Zones"])
app.include_router(loop_router, prefix="/api/loops", tags=["Loops"])
app.include_router(line_router, prefix="/api/lines", tags=["Lines"])
app.include_router(cell_router, prefix="/api/cells", tags=["Cells"])
app.include_router(plant_admin_router,
                   prefix="/api/plant-admins", tags=["Plant Admins"])
app.include_router(planner_router, prefix="/api/planners", tags=["Planners"])
app.include_router(team_leader_router,
                   prefix="/api/team-leaders", tags=["Team Leaders"])
app.include_router(member_router, prefix="/api/members", tags=["Members"])
app.include_router(shift_router, prefix="/api/shifts", tags=["Shifts"])
app.include_router(plan_router, prefix="/api/plans", tags=["Plans"])
app.include_router(production_router,
                   prefix="/api/productions", tags=["Productions"])
app.include_router(loss_reason_router,
                   prefix="/api/loss-reasons", tags=["Loss Reasons"])
app.include_router(loss_router, prefix="/api/losses", tags=["Losses"])


@app.get("/")
async def root():
    return {"message": "Welcome to Production Management API"}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
