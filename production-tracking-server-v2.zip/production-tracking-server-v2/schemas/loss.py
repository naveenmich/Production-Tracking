from pydantic import BaseModel
from database.models import Hour
from typing import Optional


class LineResponse(BaseModel):
    id: int
    name: str

    class Config:
        from_attributes = True


class LoopResponse(BaseModel):
    id: int
    name: str

    class Config:
        from_attributes = True


class ZoneResponse(BaseModel):
    id: int
    name: str

    class Config:
        from_attributes = True


class PlantResponse(BaseModel):
    id: int
    name: str

    class Config:
        from_attributes = True


class LossReasonResponse(BaseModel):
    id: str
    title: str
    department: str

    class Config:
        from_attributes = True


class ProductionResponse(BaseModel):
    id: int
    plan: int
    achievement: Optional[int]
    scraps: Optional[int]
    defects: Optional[int]
    flash: Optional[int]
    hour: Hour

    class Config:
        from_attributes = True


class LossCreate(BaseModel):
    amount: int
    loss_reason_id: str
    production_id: int


class LossResponse(BaseModel):
    id: int
    amount: int
    loss_reason: LossReasonResponse
    production: ProductionResponse
    line: LineResponse
    loop: LoopResponse
    zone: ZoneResponse
    plant: PlantResponse

    class Config:
        from_attributes = True
