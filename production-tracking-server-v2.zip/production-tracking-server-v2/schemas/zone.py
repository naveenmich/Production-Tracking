from pydantic import BaseModel


class PlantResponse(BaseModel):
    id: int
    name: str

    class Config:
        from_attributes = True


class ZoneCreate(BaseModel):
    name: str
    plant_id: int


class ZoneResponse(BaseModel):
    id: int
    name: str
    plant: PlantResponse

    class Config:
        from_attributes = True
