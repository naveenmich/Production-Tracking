from pydantic import BaseModel


class LossReasonCreate(BaseModel):
    id: str
    title: str
    department: str


class LossReasonResponse(BaseModel):
    id: str
    title: str
    department: str

    class Config:
        from_attributes = True
