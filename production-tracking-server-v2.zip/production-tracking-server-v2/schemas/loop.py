from pydantic import BaseModel


class PlantResponse(BaseModel):
    id: int
    name: str

    class Config:
        from_attributes = True


class ZoneResponse(BaseModel):
    id: int
    name: str

    class Config:
        from_attributes = True


class LoopCreate(BaseModel):
    name: str
    zone_id: int


class LoopResponse(BaseModel):
    id: int
    name: str
    zone: ZoneResponse
    plant: PlantResponse

    class Config:
        from_attributes = True
