from pydantic import BaseModel
from database.models import Hour, DayNight, ShiftType, UserRole
from datetime import date, datetime


class LineResponse(BaseModel):
    id: int
    name: str

    class Config:
        from_attributes = True


class LoopResponse(BaseModel):
    id: int
    name: str

    class Config:
        from_attributes = True


class ZoneResponse(BaseModel):
    id: int
    name: str

    class Config:
        from_attributes = True


class PlantResponse(BaseModel):
    id: int
    name: str

    class Config:
        from_attributes = True


class PlannerUserResponse(BaseModel):
    sap_id: str
    name: str
    role: UserRole

    class Config:
        from_attributes = True


class ShiftResponse(BaseModel):
    id: int
    date: date
    day_night: DayNight
    shift: ShiftType

    class Config:
        from_attributes = True


class PlanCreate(BaseModel):
    plan: int
    hour: Hour
    shift_id: int
    line_id: int
    planner_id: str


class PlanResponse(BaseModel):
    id: int
    plan: int
    achievement: int | None
    scraps: int | None
    defects: int | None
    flash: int | None
    hour: Hour
    line: LineResponse
    loop: LoopResponse
    zone: ZoneResponse
    plant: PlantResponse
    planner_user: PlannerUserResponse
    shift: ShiftResponse
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True
