from pydantic import BaseModel


class LoginRequest(BaseModel):
    sap_id: str
    password: str


class PasswordResetRequest(BaseModel):
    sap_id: str
    current_password: str
    new_password: str


class UserResponse(BaseModel):
    sap_id: str
    name: str
    role: str


class LoginResponse(BaseModel):
    user: UserResponse
    token: str
