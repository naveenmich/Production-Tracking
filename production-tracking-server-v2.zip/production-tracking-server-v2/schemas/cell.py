from pydantic import BaseModel


class PlantResponse(BaseModel):
    id: int
    name: str

    class Config:
        from_attributes = True


class ZoneResponse(BaseModel):
    id: int
    name: str

    class Config:
        from_attributes = True


class LoopResponse(BaseModel):
    id: int
    name: str

    class Config:
        from_attributes = True


class LineResponse(BaseModel):
    id: int
    name: str

    class Config:
        from_attributes = True


class CellCreate(BaseModel):
    name: str
    line_id: int


class CellResponse(BaseModel):
    id: int
    name: str
    line: LineResponse
    loop: LoopResponse
    zone: ZoneResponse
    plant: PlantResponse

    class Config:
        from_attributes = True
