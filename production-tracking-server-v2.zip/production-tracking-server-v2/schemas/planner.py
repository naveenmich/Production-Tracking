from pydantic import BaseModel
from database.models import UserRole


class PlantResponse(BaseModel):
    id: int
    name: str

    class Config:
        from_attributes = True


class UserResponse(BaseModel):
    sap_id: str
    name: str
    role: UserRole

    class Config:
        from_attributes = True


class PlannerCreate(BaseModel):
    sap_id: str
    plant_id: int


class PlannerNewCreate(BaseModel):
    sap_id: str
    name: str
    plant_id: int


class PlannerResponse(BaseModel):
    user: UserResponse
    plant: PlantResponse

    class Config:
        from_attributes = True
