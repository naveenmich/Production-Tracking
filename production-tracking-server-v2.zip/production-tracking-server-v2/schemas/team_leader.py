from pydantic import BaseModel
from database.models import UserRole


class PlantResponse(BaseModel):
    id: int
    name: str

    class Config:
        from_attributes = True


class ZoneResponse(BaseModel):
    id: int
    name: str

    class Config:
        from_attributes = True


class LoopResponse(BaseModel):
    id: int
    name: str

    class Config:
        from_attributes = True


class LineResponse(BaseModel):
    id: int
    name: str

    class Config:
        from_attributes = True


class UserResponse(BaseModel):
    sap_id: str
    name: str
    role: UserRole

    class Config:
        from_attributes = True


class TeamLeaderCreate(BaseModel):
    sap_id: str
    line_id: int


class TeamLeaderNewCreate(BaseModel):
    sap_id: str
    name: str
    line_id: int


class TeamLeaderResponse(BaseModel):
    user: UserResponse
    line: LineResponse
    loop: LoopResponse
    zone: ZoneResponse
    plant: PlantResponse

    class Config:
        from_attributes = True
