from pydantic import BaseModel


class PlantResponse(BaseModel):
    id: int
    name: str

    class Config:
        from_attributes = True


class ZoneResponse(BaseModel):
    id: int
    name: str

    class Config:
        from_attributes = True


class LoopResponse(BaseModel):
    id: int
    name: str

    class Config:
        from_attributes = True


class LineCreate(BaseModel):
    name: str
    loop_id: int


class LineResponse(BaseModel):
    id: int
    name: str
    loop: LoopResponse
    zone: ZoneResponse
    plant: PlantResponse

    class Config:
        from_attributes = True
