from pydantic import BaseModel
from database.models import DayNight, ShiftType, UserRole
from datetime import date


class PlantResponse(BaseModel):
    id: int
    name: str

    class Config:
        from_attributes = True


class PlannerResponse(BaseModel):
    sap_id: str
    name: str
    role: UserRole

    class Config:
        from_attributes = True


class ShiftCreate(BaseModel):
    date: date
    day_night: DayNight
    shift: ShiftType
    plant_id: int
    planner_id: str


class ShiftResponse(BaseModel):
    id: int
    date: date
    day_night: DayNight
    shift: ShiftType
    planner_user: PlannerResponse
    plant: PlantResponse

    class Config:
        from_attributes = True
