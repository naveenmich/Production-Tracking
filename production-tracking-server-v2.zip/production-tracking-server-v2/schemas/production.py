from pydantic import BaseModel
from database.models import Hour, DayNight, ShiftType, UserRole
from datetime import date, datetime
from typing import Optional, List


class LineResponse(BaseModel):
    id: int
    name: str

    class Config:
        from_attributes = True


class LoopResponse(BaseModel):
    id: int
    name: str

    class Config:
        from_attributes = True


class ZoneResponse(BaseModel):
    id: int
    name: str

    class Config:
        from_attributes = True


class PlantResponse(BaseModel):
    id: int
    name: str

    class Config:
        from_attributes = True


class UserResponse(BaseModel):
    sap_id: str
    name: str
    role: UserRole

    class Config:
        from_attributes = True


class ShiftResponse(BaseModel):
    id: int
    date: date
    day_night: DayNight
    shift: ShiftType

    class Config:
        from_attributes = True


class LossReasonResponse(BaseModel):
    id: str
    title: str
    department: str

    class Config:
        from_attributes = True


class LossResponse(BaseModel):
    id: int
    amount: int
    loss_reason: LossReasonResponse

    class Config:
        from_attributes = True


class ProductionUpdate(BaseModel):
    achievement: int
    scraps: int
    defects: int
    flash: int
    team_leader_id: str


class ProductionResponse(BaseModel):
    id: int
    plan: int
    achievement: Optional[int]
    scraps: Optional[int]
    defects: Optional[int]
    flash: Optional[int]
    hour: Hour
    line: LineResponse
    loop: LoopResponse
    zone: ZoneResponse
    plant: PlantResponse
    planner_user: UserResponse
    team_leader_user: Optional[UserResponse]
    shift: ShiftResponse
    losses: List[LossResponse]
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True
