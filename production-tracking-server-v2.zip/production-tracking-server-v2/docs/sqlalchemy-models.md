```py
from sqlalchemy import Column, Integer, String, ForeignKey, DateTime, Enum, Date
from sqlalchemy.orm import relationship
from sqlalchemy.ext.declarative import declarative_base
from datetime import datetime
import enum

Base = declarative_base()

# Enum Classes


class UserRole(str, enum.Enum):
    ADMIN = "ADMIN"
    PLANT_ADMIN = "PLANT_ADMIN"
    PLANNER = "PLANNER"
    TEAM_LEADER = "TEAM_LEADER"
    MEMBER = "MEMBER"


class DayNight(str, enum.Enum):
    DAY = "DAY"
    NIGHT = "NIGHT"


class ShiftType(str, enum.Enum):
    SHIFT_A = "SHIFT-A"
    SHIFT_B = "SHIFT-B"
    SHIFT_C = "SHIFT-C"


class Hour(str, enum.Enum):
    HOUR_01 = "HOUR-01"
    HOUR_02 = "HOUR-02"
    HOUR_03 = "HOUR-03"
    HOUR_04 = "HOUR-04"
    HOUR_05 = "HOUR-05"
    HOUR_06 = "HOUR-06"
    HOUR_07 = "HOUR-07"
    HOUR_08 = "HOUR-08"
    HOUR_09 = "HOUR-09"
    HOUR_10 = "HOUR-10"
    HOUR_11 = "HOUR-11"
    HOUR_12 = "HOUR-12"

# Models


class Plant(Base):
    __tablename__ = "plant"

    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String, unique=True, nullable=False)

    # Relationships
    zones = relationship("Zone", back_populates="plant")
    plant_admins = relationship("PlantAdmin", back_populates="plant")
    planners = relationship("Planner", back_populates="plant")
    shifts = relationship("Shift", back_populates="plant")


class Zone(Base):
    __tablename__ = "zone"

    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String, nullable=False)
    plant_id = Column(Integer, ForeignKey("plant.id"), nullable=False)

    # Relationships
    plant = relationship("Plant", back_populates="zones")
    loops = relationship("Loop", back_populates="zone")


class Loop(Base):
    __tablename__ = "loop"

    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String, nullable=False)
    zone_id = Column(Integer, ForeignKey("zone.id"), nullable=False)

    # Relationships
    zone = relationship("Zone", back_populates="loops")
    lines = relationship("Line", back_populates="loop")
    plant = relationship(
        "Plant",
        secondary="zone",
        primaryjoin="Loop.zone_id == Zone.id",
        secondaryjoin="Zone.plant_id == Plant.id",
        viewonly=True,
        uselist=False
    )


class Line(Base):
    __tablename__ = "line"

    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String, nullable=False)
    loop_id = Column(Integer, ForeignKey("loop.id"), nullable=False)

    # Relationships
    loop = relationship("Loop", back_populates="lines")
    cells = relationship("Cell", back_populates="line")
    team_leaders = relationship("TeamLeader", back_populates="line")
    productions = relationship("Production", back_populates="line")

    # Zone relationship through Loop
    zone = relationship(
        "Zone",
        secondary="loop",
        primaryjoin="Line.loop_id == Loop.id",
        secondaryjoin="Loop.zone_id == Zone.id",
        viewonly=True,
        uselist=False
    )

    # Plant relationship through Loop and Zone
    plant = relationship(
        "Plant",
        secondary="join(Loop, Zone)",
        primaryjoin="Line.loop_id == Loop.id",
        secondaryjoin="Zone.plant_id == Plant.id",
        viewonly=True,
        uselist=False
    )


class Cell(Base):
    __tablename__ = "cell"

    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String, nullable=False)
    line_id = Column(Integer, ForeignKey("line.id"), nullable=False)

    # Relationships
    line = relationship("Line", back_populates="cells")
    members = relationship("Member", back_populates="cell")
    working_members = relationship("Attendance", back_populates="working_cell")

    # Loop relationship through Line
    loop = relationship(
        "Loop",
        secondary="line",
        primaryjoin="Cell.line_id == Line.id",
        secondaryjoin="Line.loop_id == Loop.id",
        viewonly=True,
        uselist=False
    )

    # Zone relationship through Line and Loop
    zone = relationship(
        "Zone",
        secondary="join(Line, Loop)",
        primaryjoin="Cell.line_id == Line.id",
        secondaryjoin="Loop.zone_id == Zone.id",
        viewonly=True,
        uselist=False
    )

    # Plant relationship through Line, Loop, and Zone
    plant = relationship(
        "Plant",
        secondary="join(Line, Loop).join(Zone)",
        primaryjoin="Cell.line_id == Line.id",
        secondaryjoin="Zone.plant_id == Plant.id",
        viewonly=True,
        uselist=False
    )


class User(Base):
    __tablename__ = "user"

    sap_id = Column(String, primary_key=True)
    name = Column(String, nullable=False)
    role = Column(Enum(UserRole), nullable=False)
    password = Column(String, nullable=False)

    # Relationships
    admin = relationship("Admin", back_populates="user", uselist=False)
    plant_admin = relationship(
        "PlantAdmin", back_populates="user", uselist=False)
    planner = relationship("Planner", back_populates="user", uselist=False)
    team_leader = relationship(
        "TeamLeader", back_populates="user", uselist=False)
    member = relationship("Member", back_populates="user", uselist=False)


class Admin(Base):
    __tablename__ = "admin"

    user_id = Column(String, ForeignKey("user.sap_id"), primary_key=True)

    # Relationships
    user = relationship("User", back_populates="admin")


class PlantAdmin(Base):
    __tablename__ = "plant_admin"

    user_id = Column(String, ForeignKey("user.sap_id"), primary_key=True)
    plant_id = Column(Integer, ForeignKey("plant.id"), nullable=False)

    # Relationships
    user = relationship("User", back_populates="plant_admin")
    plant = relationship("Plant", back_populates="plant_admins")


class Planner(Base):
    __tablename__ = "planner"

    user_id = Column(String, ForeignKey("user.sap_id"), primary_key=True)
    plant_id = Column(Integer, ForeignKey("plant.id"), nullable=False)

    # Relationships
    user = relationship("User", back_populates="planner")
    plant = relationship("Plant", back_populates="planners")
    shifts = relationship("Shift", back_populates="planner")
    productions = relationship("Production", back_populates="planner")


class TeamLeader(Base):
    __tablename__ = "team_leader"

    user_id = Column(String, ForeignKey("user.sap_id"), primary_key=True)
    line_id = Column(Integer, ForeignKey("line.id"), nullable=False)

    # Relationships
    user = relationship("User", back_populates="team_leader")
    line = relationship("Line", back_populates="team_leaders")
    attendances = relationship("Attendance", back_populates="team_leader")
    productions = relationship("Production", back_populates="team_leader")

    loop = relationship(
        "Loop",
        secondary="line",
        primaryjoin="TeamLeader.line_id == Line.id",
        secondaryjoin="Line.loop_id == Loop.id",
        viewonly=True,
        uselist=False
    )

    zone = relationship(
        "Zone",
        secondary="join(Line, Loop)",
        primaryjoin="TeamLeader.line_id == Line.id",
        secondaryjoin="Loop.zone_id == Zone.id",
        viewonly=True,
        uselist=False
    )

    plant = relationship(
        "Plant",
        secondary="join(Line, Loop).join(Zone)",
        primaryjoin="TeamLeader.line_id == Line.id",
        secondaryjoin="Zone.plant_id == Plant.id",
        viewonly=True,
        uselist=False
    )


class Member(Base):
    __tablename__ = "member"

    user_id = Column(String, ForeignKey("user.sap_id"), primary_key=True)
    cell_id = Column(Integer, ForeignKey("cell.id"), nullable=False)

    # Relationships
    user = relationship("User", back_populates="member")
    cell = relationship("Cell", back_populates="members")
    attendances = relationship("Attendance", back_populates="member")

    # Line relationship through Cell
    line = relationship(
        "Line",
        secondary="cell",
        primaryjoin="Member.cell_id == Cell.id",
        secondaryjoin="Cell.line_id == Line.id",
        viewonly=True,
        uselist=False
    )

    # Loop relationship through Cell and Line
    loop = relationship(
        "Loop",
        secondary="join(Cell, Line)",
        primaryjoin="Member.cell_id == Cell.id",
        secondaryjoin="Line.loop_id == Loop.id",
        viewonly=True,
        uselist=False
    )

    # Zone relationship through Cell, Line, and Loop
    zone = relationship(
        "Zone",
        secondary="join(Cell, Line).join(Loop)",
        primaryjoin="Member.cell_id == Cell.id",
        secondaryjoin="Loop.zone_id == Zone.id",
        viewonly=True,
        uselist=False
    )

    # Plant relationship through Cell, Line, Loop, and Zone
    plant = relationship(
        "Plant",
        secondary="join(Cell, Line).join(Loop).join(Zone)",
        primaryjoin="Member.cell_id == Cell.id",
        secondaryjoin="Zone.plant_id == Plant.id",
        viewonly=True,
        uselist=False
    )


class Shift(Base):
    __tablename__ = "shift"

    id = Column(Integer, primary_key=True, autoincrement=True)
    date = Column(Date, nullable=False)
    day_night = Column(Enum(DayNight), nullable=False)
    shift = Column(Enum(ShiftType), nullable=False)
    plant_id = Column(Integer, ForeignKey("plant.id"), nullable=False)
    planner_id = Column(String, ForeignKey("planner.user_id"), nullable=False)

    # Relationships
    plant = relationship("Plant", back_populates="shifts")
    planner = relationship("Planner", back_populates="shifts")
    productions = relationship("Production", back_populates="shift")
    attendances = relationship("Attendance", back_populates="shift")


class Production(Base):
    __tablename__ = "production"

    id = Column(Integer, primary_key=True, autoincrement=True)
    plan = Column(Integer, nullable=False)
    achievement = Column(Integer, nullable=False)
    scraps = Column(Integer, nullable=False)
    defects = Column(Integer, nullable=False)
    flash = Column(Integer, nullable=False)
    hour = Column(Enum(Hour), nullable=False)
    line_id = Column(Integer, ForeignKey("line.id"), nullable=False)
    shift_id = Column(Integer, ForeignKey("shift.id"), nullable=False)
    planner_id = Column(String, ForeignKey("planner.user_id"), nullable=False)
    team_leader_id = Column(String, ForeignKey(
        "team_leader.user_id"), nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow,
                        onupdate=datetime.utcnow)

    # Relationships
    line = relationship("Line", back_populates="productions")
    shift = relationship("Shift", back_populates="productions")
    planner = relationship("Planner", back_populates="productions")
    team_leader = relationship("TeamLeader", back_populates="productions")
    losses = relationship("Loss", back_populates="production")

    # Loop relationship through Line
    loop = relationship(
        "Loop",
        secondary="line",
        primaryjoin="Production.line_id == Line.id",
        secondaryjoin="Line.loop_id == Loop.id",
        viewonly=True,
        uselist=False
    )

    # Zone relationship through Line and Loop
    zone = relationship(
        "Zone",
        secondary="join(Line, Loop)",
        primaryjoin="Production.line_id == Line.id",
        secondaryjoin="Loop.zone_id == Zone.id",
        viewonly=True,
        uselist=False
    )

    # Plant relationship through Line, Loop, and Zone
    plant = relationship(
        "Plant",
        secondary="join(Line, Loop).join(Zone)",
        primaryjoin="Production.line_id == Line.id",
        secondaryjoin="Zone.plant_id == Plant.id",
        viewonly=True,
        uselist=False
    )


class LossReason(Base):
    __tablename__ = "loss_reason"

    id = Column(String, primary_key=True)
    title = Column(String, unique=True, nullable=False)
    department = Column(String, nullable=False)

    # Relationships
    losses = relationship("Loss", back_populates="loss_reason")


class Loss(Base):
    __tablename__ = "loss"

    id = Column(Integer, primary_key=True, autoincrement=True)
    amount = Column(Integer, nullable=False)
    loss_reason_id = Column(String, ForeignKey(
        "loss_reason.id"), nullable=False)
    production_id = Column(Integer, ForeignKey(
        "production.id"), nullable=False)

    # Relationships
    loss_reason = relationship("LossReason", back_populates="losses")
    production = relationship("Production", back_populates="losses")

    # Loop relationship through Production and Line
    loop = relationship(
        "Loop",
        secondary="join(Production, Line)",
        primaryjoin="Loss.production_id == Production.id",
        secondaryjoin="Line.loop_id == Loop.id",
        viewonly=True,
        uselist=False
    )

    # Zone relationship through Production, Line, and Loop
    zone = relationship(
        "Zone",
        secondary="join(Production, Line).join(Loop)",
        primaryjoin="Loss.production_id == Production.id",
        secondaryjoin="Loop.zone_id == Zone.id",
        viewonly=True,
        uselist=False
    )

    # Plant relationship through Production, Line, Loop, and Zone
    plant = relationship(
        "Plant",
        secondary="join(Production, Line).join(Loop).join(Zone)",
        primaryjoin="Loss.production_id == Production.id",
        secondaryjoin="Zone.plant_id == Plant.id",
        viewonly=True,
        uselist=False
    )


class AttendanceType(Base):
    __tablename__ = "attendance_type"

    id = Column(String, primary_key=True)
    title = Column(String, unique=True, nullable=False)
    color = Column(String, unique=True, nullable=False)

    # Relationships
    attendances = relationship("Attendance", back_populates="attendance_type")


class Attendance(Base):
    __tablename__ = "attendance"

    id = Column(Integer, primary_key=True, autoincrement=True)
    member_id = Column(String, ForeignKey("member.user_id"), nullable=False)
    attendance_type_id = Column(String, ForeignKey(
        "attendance_type.id"), nullable=False)
    shift_id = Column(Integer, ForeignKey("shift.id"), nullable=False)
    working_cell_id = Column(Integer, ForeignKey("cell.id"), nullable=False)
    team_leader_id = Column(String, ForeignKey(
        "team_leader.user_id"), nullable=False)

    # Relationships
    member = relationship("Member", back_populates="attendances")
    attendance_type = relationship(
        "AttendanceType", back_populates="attendances")
    shift = relationship("Shift", back_populates="attendances")
    working_cell = relationship("Cell", back_populates="working_members")
    team_leader = relationship("TeamLeader", back_populates="attendances")

    # Line relationship through working Cell
    line = relationship(
        "Line",
        secondary="cell",
        primaryjoin="Attendance.working_cell_id == Cell.id",
        secondaryjoin="Cell.line_id == Line.id",
        viewonly=True,
        uselist=False
    )

    # Loop relationship through working Cell and Line
    loop = relationship(
        "Loop",
        secondary="join(Cell, Line)",
        primaryjoin="Attendance.working_cell_id == Cell.id",
        secondaryjoin="Line.loop_id == Loop.id",
        viewonly=True,
        uselist=False
    )

    # Zone relationship through working Cell, Line, and Loop
    zone = relationship(
        "Zone",
        secondary="join(Cell, Line).join(Loop)",
        primaryjoin="Attendance.working_cell_id == Cell.id",
        secondaryjoin="Loop.zone_id == Zone.id",
        viewonly=True,
        uselist=False
    )

    # Plant relationship through working Cell, Line, Loop, and Zone
    plant = relationship(
        "Plant",
        secondary="join(Cell, Line).join(Loop).join(Zone)",
        primaryjoin="Attendance.working_cell_id == Cell.id",
        secondaryjoin="Zone.plant_id == Plant.id",
        viewonly=True,
        uselist=False
    )

```