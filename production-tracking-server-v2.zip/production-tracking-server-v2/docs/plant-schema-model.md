```py
from pydantic import BaseModel


class PlantCreate(BaseModel):
    name: str


class PlantResponse(BaseModel):
    id: int
    name: str

    class Config:
        from_attributes = True

```