```py
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from database.service import init_db
from routes.auth.route import router as auth_router
from routes.plant.route import router as plant_router

# Initialize database
init_db()

# Create FastAPI app
app = FastAPI(
    title="Production Management API",
    description="API for managing production data",
    version="1.0.0"
)

# Configure CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # In production, replace with actual frontend domain
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include routers
app.include_router(auth_router, prefix="/api/auth", tags=["Authentication"])
app.include_router(plant_router, prefix="/api/plants", tags=["Plants"])


@app.get("/")
async def root():
    return {"message": "Welcome to Production Management API"}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)


```