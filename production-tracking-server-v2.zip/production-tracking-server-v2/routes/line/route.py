from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from database.models import Line, Loop, Zone
from database.service import get_db
from schemas.line import LineCreate, LineResponse
from typing import List, Optional

router = APIRouter()


@router.post("", response_model=LineResponse, status_code=status.HTTP_201_CREATED)
async def create_line(line: LineCreate, db: Session = Depends(get_db)):
    # Check if loop exists
    loop = db.query(Loop).filter(Loop.id == line.loop_id).first()
    if not loop:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Loop not found"
        )

    # Create new line
    new_line = Line(**line.model_dump())
    db.add(new_line)
    db.commit()
    db.refresh(new_line)

    return new_line


@router.get("", response_model=List[LineResponse])
async def get_lines(
    plant_id: Optional[int] = None,
    zone_id: Optional[int] = None,
    loop_id: Optional[int] = None,
    db: Session = Depends(get_db)
):
    query = db.query(Line)

    if loop_id:
        query = query.filter(Line.loop_id == loop_id)

    if zone_id:
        query = query.join(Loop).filter(Loop.zone_id == zone_id)

    if plant_id:
        query = query.join(Loop).join(Zone).filter(Zone.plant_id == plant_id)

    lines = query.all()
    return lines


@router.get("/{line_id}", response_model=LineResponse)
async def get_line(line_id: int, db: Session = Depends(get_db)):
    line = db.query(Line).filter(Line.id == line_id).first()
    if not line:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Line not found"
        )
    return line
