from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from database.models import Cell, Line, Loop, Zone
from database.service import get_db
from schemas.cell import CellCreate, CellResponse
from typing import List, Optional

router = APIRouter()


@router.post("", response_model=CellResponse, status_code=status.HTTP_201_CREATED)
async def create_cell(cell: CellCreate, db: Session = Depends(get_db)):
    # Check if line exists
    line = db.query(Line).filter(Line.id == cell.line_id).first()
    if not line:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Line not found"
        )

    # Create new cell
    new_cell = Cell(**cell.model_dump())
    db.add(new_cell)
    db.commit()
    db.refresh(new_cell)

    return new_cell


@router.get("", response_model=List[CellResponse])
async def get_cells(
    plant_id: Optional[int] = None,
    zone_id: Optional[int] = None,
    loop_id: Optional[int] = None,
    line_id: Optional[int] = None,
    db: Session = Depends(get_db)
):
    query = db.query(Cell)

    if line_id:
        query = query.filter(Cell.line_id == line_id)

    if loop_id:
        query = query.join(Line).filter(Line.loop_id == loop_id)

    if zone_id:
        query = query.join(Line).join(Loop).filter(Loop.zone_id == zone_id)

    if plant_id:
        query = query.join(Line).join(Loop).join(
            Zone).filter(Zone.plant_id == plant_id)

    cells = query.all()
    return cells


@router.get("/{cell_id}", response_model=CellResponse)
async def get_cell(cell_id: int, db: Session = Depends(get_db)):
    cell = db.query(Cell).filter(Cell.id == cell_id).first()
    if not cell:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Cell not found"
        )
    return cell
