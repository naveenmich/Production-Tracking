from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from database.models import Member, Cell, Line, Loop, Zone, Plant, User, UserRole
from database.service import get_db
from schemas.member import MemberCreate, MemberNewCreate, MemberResponse
from typing import List, Optional

router = APIRouter()


@router.post("", response_model=MemberResponse, status_code=status.HTTP_201_CREATED)
async def create_member(member: MemberCreate, db: Session = Depends(get_db)):
    # Check if user exists
    user = db.query(User).filter(User.sap_id == member.sap_id).first()
    if not user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="User not found"
        )

    # Check if cell exists
    cell = db.query(Cell).filter(Cell.id == member.cell_id).first()
    if not cell:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Cell not found"
        )

    # Check if member already exists
    existing_member = db.query(Member).filter(
        Member.user_id == member.sap_id
    ).first()
    if existing_member:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Member already exists for this user"
        )

    # Create new member
    new_member = Member(
        user_id=member.sap_id,
        cell_id=member.cell_id
    )

    # Update user role to MEMBER
    user.role = UserRole.MEMBER

    db.add(new_member)
    db.commit()
    db.refresh(new_member)

    return new_member


@router.post("/new", response_model=MemberResponse, status_code=status.HTTP_201_CREATED)
async def create_new_member(member: MemberNewCreate, db: Session = Depends(get_db)):
    # Check if user already exists
    existing_user = db.query(User).filter(User.sap_id == member.sap_id).first()
    if existing_user:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="User with this SAP ID already exists"
        )

    # Check if cell exists
    cell = db.query(Cell).filter(Cell.id == member.cell_id).first()
    if not cell:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Cell not found"
        )

    # Create new user with SAP ID as password
    new_user = User(
        sap_id=member.sap_id,
        name=member.name,
        role=UserRole.MEMBER,
        password=member.sap_id  # In production, this should be hashed
    )
    db.add(new_user)

    # Create new member
    new_member = Member(
        user_id=member.sap_id,
        cell_id=member.cell_id
    )
    db.add(new_member)

    db.commit()
    db.refresh(new_member)

    return new_member


@router.get("", response_model=List[MemberResponse])
async def get_members(
    plant_id: Optional[int] = None,
    zone_id: Optional[int] = None,
    loop_id: Optional[int] = None,
    line_id: Optional[int] = None,
    cell_id: Optional[int] = None,
    user_id: Optional[str] = None,
    db: Session = Depends(get_db)
):
    query = db.query(Member)

    if cell_id:
        query = query.filter(Member.cell_id == cell_id)

    if line_id:
        query = query.join(Cell).filter(Cell.line_id == line_id)

    if loop_id:
        query = query.join(Cell).join(Line).filter(Line.loop_id == loop_id)

    if zone_id:
        query = query.join(Cell).join(Line).join(
            Loop).filter(Loop.zone_id == zone_id)

    if plant_id:
        query = query.join(Cell).join(Line).join(Loop).join(
            Zone).filter(Zone.plant_id == plant_id)

    if user_id:
        query = query.filter(Member.user_id == user_id)

    members = query.all()
    return members


@router.get("/{user_id}", response_model=MemberResponse)
async def get_member(user_id: str, db: Session = Depends(get_db)):
    member = db.query(Member).filter(Member.user_id == user_id).first()
    if not member:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Member not found"
        )
    return member
