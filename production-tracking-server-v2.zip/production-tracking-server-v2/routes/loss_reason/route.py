from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from database.models import LossReason
from database.service import get_db
from schemas.loss_reason import LossReasonCreate, LossReasonResponse
from typing import List, Optional

router = APIRouter()


@router.post("", response_model=LossReasonResponse, status_code=status.HTTP_201_CREATED)
async def create_loss_reason(loss_reason: LossReasonCreate, db: Session = Depends(get_db)):
    # Check if loss reason with same id exists
    existing_id = db.query(LossReason).filter(
        LossReason.id == loss_reason.id).first()
    if existing_id:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Loss reason with this ID already exists"
        )

    # Check if loss reason with same title exists
    existing_title = db.query(LossReason).filter(
        LossReason.title == loss_reason.title).first()
    if existing_title:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Loss reason with this title already exists"
        )

    # Create new loss reason
    new_loss_reason = LossReason(**loss_reason.model_dump())
    db.add(new_loss_reason)
    db.commit()
    db.refresh(new_loss_reason)

    return new_loss_reason


@router.get("", response_model=List[LossReasonResponse])
async def get_loss_reasons(department: Optional[str] = None, db: Session = Depends(get_db)):
    query = db.query(LossReason)

    if department:
        query = query.filter(LossReason.department == department)

    loss_reasons = query.all()
    return loss_reasons


@router.get("/{loss_reason_id}", response_model=LossReasonResponse)
async def get_loss_reason(loss_reason_id: str, db: Session = Depends(get_db)):
    loss_reason = db.query(LossReason).filter(
        LossReason.id == loss_reason_id).first()
    if not loss_reason:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Loss reason not found"
        )
    return loss_reason
