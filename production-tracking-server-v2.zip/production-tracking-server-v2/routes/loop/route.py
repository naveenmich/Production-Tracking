from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from database.models import Loop, Zone
from database.service import get_db
from schemas.loop import LoopCreate, LoopResponse
from typing import List, Optional

router = APIRouter()


@router.post("", response_model=LoopResponse, status_code=status.HTTP_201_CREATED)
async def create_loop(loop: LoopCreate, db: Session = Depends(get_db)):
    # Check if zone exists
    zone = db.query(Zone).filter(Zone.id == loop.zone_id).first()
    if not zone:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Zone not found"
        )

    # Create new loop
    new_loop = Loop(**loop.model_dump())
    db.add(new_loop)
    db.commit()
    db.refresh(new_loop)

    return new_loop


@router.get("", response_model=List[LoopResponse])
async def get_loops(
    plant_id: Optional[int] = None,
    zone_id: Optional[int] = None,
    db: Session = Depends(get_db)
):
    query = db.query(Loop)

    if zone_id:
        query = query.filter(Loop.zone_id == zone_id)

    if plant_id:
        query = query.join(Zone).filter(Zone.plant_id == plant_id)

    loops = query.all()
    return loops


@router.get("/{loop_id}", response_model=LoopResponse)
async def get_loop(loop_id: int, db: Session = Depends(get_db)):
    loop = db.query(Loop).filter(Loop.id == loop_id).first()
    if not loop:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Loop not found"
        )
    return loop
