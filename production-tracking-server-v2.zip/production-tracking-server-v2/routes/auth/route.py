from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from database.models import User
from database.service import get_db
from utils.jwt import create_access_token
from schemas.auth import LoginRequest, PasswordResetRequest, LoginResponse, UserResponse

router = APIRouter()


@router.post("/login", response_model=LoginResponse)
async def login(request: LoginRequest, db: Session = Depends(get_db)):
    # Find user by SAP ID
    user = db.query(User).filter(User.sap_id == request.sap_id).first()

    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid credentials"
        )

    # Verify password
    if user.password != request.password:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid credentials"
        )

    # Create token
    token = create_access_token({"sub": user.sap_id, "role": user.role})

    # Return user data and token
    return LoginResponse(
        user=UserResponse(
            sap_id=user.sap_id,
            name=user.name,
            role=user.role
        ),
        token=token
    )


@router.post("/reset-password", status_code=status.HTTP_200_OK)
async def reset_password(request: PasswordResetRequest, db: Session = Depends(get_db)):
    # Find user by SAP ID
    user = db.query(User).filter(User.sap_id == request.sap_id).first()

    if not user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="User not found"
        )

    # Verify current password
    if user.password != request.current_password:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Current password is incorrect"
        )

    # Update password
    user.password = request.new_password
    db.commit()

    return {"message": "Password updated successfully"}
