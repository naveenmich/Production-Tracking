from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from database.models import Plant
from database.service import get_db
from schemas.plant import PlantCreate, PlantResponse
from typing import List

router = APIRouter()


@router.post("", response_model=PlantResponse, status_code=status.HTTP_201_CREATED)
async def create_plant(plant: PlantCreate, db: Session = Depends(get_db)):
    # Check if plant with same name exists
    db_plant = db.query(Plant).filter(Plant.name == plant.name).first()
    if db_plant:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Plant with this name already exists"
        )

    # Create new plant
    new_plant = Plant(**plant.model_dump())
    db.add(new_plant)
    db.commit()
    db.refresh(new_plant)

    return new_plant


@router.get("", response_model=List[PlantResponse])
async def get_plants(db: Session = Depends(get_db)):
    plants = db.query(Plant).all()
    return plants


@router.get("/{plant_id}", response_model=PlantResponse)
async def get_plant(plant_id: int, db: Session = Depends(get_db)):
    plant = db.query(Plant).filter(Plant.id == plant_id).first()
    if not plant:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Plant not found"
        )
    return plant
