from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from database.models import Shift, Plant, Planner, User, DayNight
from database.service import get_db
from schemas.shift import ShiftCreate, ShiftResponse
from typing import List, Optional
from datetime import date

router = APIRouter()


@router.post("", response_model=ShiftResponse, status_code=status.HTTP_201_CREATED)
async def create_shift(shift: ShiftCreate, db: Session = Depends(get_db)):
    # Check if plant exists
    plant = db.query(Plant).filter(Plant.id == shift.plant_id).first()
    if not plant:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Plant not found"
        )

    # Check if planner exists
    planner = db.query(Planner).filter(
        Planner.user_id == shift.planner_id).first()
    if not planner:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Planner not found"
        )

    # Check if shift already exists for this date, day_night, and plant
    existing_shift = db.query(Shift).filter(
        Shift.date == shift.date,
        Shift.day_night == shift.day_night,
        Shift.plant_id == shift.plant_id
    ).first()
    if existing_shift:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Shift already exists for this date ({shift.date}) and {shift.day_night} shift"
        )

    # Create new shift
    new_shift = Shift(**shift.model_dump())
    db.add(new_shift)
    db.commit()
    db.refresh(new_shift)

    return new_shift


@router.get("", response_model=List[ShiftResponse])
async def get_shifts(
    plant_id: Optional[int] = None,
    date_value: Optional[date] = None,
    day_night: Optional[DayNight] = None,
    planner_id: Optional[str] = None,
    db: Session = Depends(get_db)
):
    query = db.query(Shift)

    if plant_id:
        query = query.filter(Shift.plant_id == plant_id)

    if date_value:
        query = query.filter(Shift.date == date_value)

    if day_night:
        query = query.filter(Shift.day_night == day_night)

    if planner_id:
        query = query.filter(Shift.planner_id == planner_id)

    shifts = query.all()
    return shifts


@router.get("/{shift_id}", response_model=ShiftResponse)
async def get_shift(shift_id: int, db: Session = Depends(get_db)):
    shift = db.query(Shift).filter(Shift.id == shift_id).first()
    if not shift:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Shift not found"
        )
    return shift
