from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from database.models import Planner, Plant, User, UserRole
from database.service import get_db
from schemas.planner import PlannerCreate, PlannerNewCreate, PlannerResponse
from typing import List, Optional

router = APIRouter()


@router.post("", response_model=PlannerResponse, status_code=status.HTTP_201_CREATED)
async def create_planner(planner: PlannerCreate, db: Session = Depends(get_db)):
    # Check if user exists
    user = db.query(User).filter(User.sap_id == planner.sap_id).first()
    if not user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="User not found"
        )

    # Check if plant exists
    plant = db.query(Plant).filter(Plant.id == planner.plant_id).first()
    if not plant:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Plant not found"
        )

    # Check if planner already exists
    existing_planner = db.query(Planner).filter(
        Planner.user_id == planner.sap_id
    ).first()
    if existing_planner:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Planner already exists for this user"
        )

    # Create new planner
    new_planner = Planner(
        user_id=planner.sap_id,
        plant_id=planner.plant_id
    )

    # Update user role to PLANNER
    user.role = UserRole.PLANNER

    db.add(new_planner)
    db.commit()
    db.refresh(new_planner)

    return new_planner


@router.post("/new", response_model=PlannerResponse, status_code=status.HTTP_201_CREATED)
async def create_new_planner(planner: PlannerNewCreate, db: Session = Depends(get_db)):
    # Check if user already exists
    existing_user = db.query(User).filter(
        User.sap_id == planner.sap_id).first()
    if existing_user:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="User with this SAP ID already exists"
        )

    # Check if plant exists
    plant = db.query(Plant).filter(Plant.id == planner.plant_id).first()
    if not plant:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Plant not found"
        )

    # Create new user with SAP ID as password
    new_user = User(
        sap_id=planner.sap_id,
        name=planner.name,
        role=UserRole.PLANNER,
        password=planner.sap_id  # In production, this should be hashed
    )
    db.add(new_user)

    # Create new planner
    new_planner = Planner(
        user_id=planner.sap_id,
        plant_id=planner.plant_id
    )
    db.add(new_planner)

    db.commit()
    db.refresh(new_planner)

    return new_planner


@router.get("", response_model=List[PlannerResponse])
async def get_planners(
    plant_id: Optional[int] = None,
    user_id: Optional[str] = None,
    db: Session = Depends(get_db)
):
    query = db.query(Planner)

    if plant_id:
        query = query.filter(Planner.plant_id == plant_id)

    if user_id:
        query = query.filter(Planner.user_id == user_id)

    planners = query.all()
    return planners


@router.get("/{user_id}", response_model=PlannerResponse)
async def get_planner(user_id: str, db: Session = Depends(get_db)):
    planner = db.query(Planner).filter(Planner.user_id == user_id).first()
    if not planner:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Planner not found"
        )
    return planner
