from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from database.models import TeamLeader, Line, Loop, Zone, Plant, User, UserRole
from database.service import get_db
from schemas.team_leader import TeamLeaderCreate, TeamLeaderNewCreate, TeamLeaderResponse
from typing import List, Optional

router = APIRouter()


@router.post("", response_model=TeamLeaderResponse, status_code=status.HTTP_201_CREATED)
async def create_team_leader(team_leader: TeamLeaderCreate, db: Session = Depends(get_db)):
    # Check if user exists
    user = db.query(User).filter(User.sap_id == team_leader.sap_id).first()
    if not user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="User not found"
        )

    # Check if line exists
    line = db.query(Line).filter(Line.id == team_leader.line_id).first()
    if not line:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Line not found"
        )

    # Check if team leader already exists
    existing_team_leader = db.query(TeamLeader).filter(
        TeamLeader.user_id == team_leader.sap_id
    ).first()
    if existing_team_leader:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Team Leader already exists for this user"
        )

    # Create new team leader
    new_team_leader = TeamLeader(
        user_id=team_leader.sap_id,
        line_id=team_leader.line_id
    )

    # Update user role to TEAM_LEADER
    user.role = UserRole.TEAM_LEADER

    db.add(new_team_leader)
    db.commit()
    db.refresh(new_team_leader)

    return new_team_leader


@router.post("/new", response_model=TeamLeaderResponse, status_code=status.HTTP_201_CREATED)
async def create_new_team_leader(team_leader: TeamLeaderNewCreate, db: Session = Depends(get_db)):
    # Check if user already exists
    existing_user = db.query(User).filter(
        User.sap_id == team_leader.sap_id).first()
    if existing_user:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="User with this SAP ID already exists"
        )

    # Check if line exists
    line = db.query(Line).filter(Line.id == team_leader.line_id).first()
    if not line:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Line not found"
        )

    # Create new user with SAP ID as password
    new_user = User(
        sap_id=team_leader.sap_id,
        name=team_leader.name,
        role=UserRole.TEAM_LEADER,
        password=team_leader.sap_id  # In production, this should be hashed
    )
    db.add(new_user)

    # Create new team leader
    new_team_leader = TeamLeader(
        user_id=team_leader.sap_id,
        line_id=team_leader.line_id
    )
    db.add(new_team_leader)

    db.commit()
    db.refresh(new_team_leader)

    return new_team_leader


@router.get("", response_model=List[TeamLeaderResponse])
async def get_team_leaders(
    plant_id: Optional[int] = None,
    zone_id: Optional[int] = None,
    loop_id: Optional[int] = None,
    line_id: Optional[int] = None,
    user_id: Optional[str] = None,
    db: Session = Depends(get_db)
):
    query = db.query(TeamLeader)

    if line_id:
        query = query.filter(TeamLeader.line_id == line_id)

    if loop_id:
        query = query.join(Line).filter(Line.loop_id == loop_id)

    if zone_id:
        query = query.join(Line).join(Loop).filter(Loop.zone_id == zone_id)

    if plant_id:
        query = query.join(Line).join(Loop).join(
            Zone).filter(Zone.plant_id == plant_id)

    if user_id:
        query = query.filter(TeamLeader.user_id == user_id)

    team_leaders = query.all()
    return team_leaders


@router.get("/{user_id}", response_model=TeamLeaderResponse)
async def get_team_leader(user_id: str, db: Session = Depends(get_db)):
    team_leader = db.query(TeamLeader).filter(
        TeamLeader.user_id == user_id).first()
    if not team_leader:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Team Leader not found"
        )
    return team_leader
