from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from database.models import Loop, Production, Line, Shift, TeamLeader, User, Hour, Zone
from database.service import get_db
from schemas.production import ProductionUpdate, ProductionResponse
from typing import List, Optional
from datetime import date

router = APIRouter()


@router.post("/{production_id}", response_model=ProductionResponse)
async def update_production(
    production_id: int,
    production_data: ProductionUpdate,
    db: Session = Depends(get_db)
):
    # Check if production exists
    production = db.query(Production).filter(
        Production.id == production_id).first()
    if not production:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Production not found"
        )

    # Check if team leader exists
    team_leader = db.query(TeamLeader).filter(
        TeamLeader.user_id == production_data.team_leader_id
    ).first()
    if not team_leader:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Team Leader not found"
        )

    # Check if team leader belongs to the same line
    if team_leader.line_id != production.line_id:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Team Leader does not belong to this production line"
        )

    # Update production data
    for field, value in production_data.model_dump().items():
        setattr(production, field, value)

    db.commit()
    db.refresh(production)

    return production


@router.get("", response_model=List[ProductionResponse])
async def get_productions(
    plant_id: Optional[int] = None,
    zone_id: Optional[int] = None,
    loop_id: Optional[int] = None,
    line_id: Optional[int] = None,
    date_value: Optional[date] = None,
    day_night: Optional[str] = None,
    planner_id: Optional[str] = None,
    team_leader_id: Optional[str] = None,
    shift_id: Optional[int] = None,
    hour: Optional[Hour] = None,
    db: Session = Depends(get_db)
):
    query = db.query(Production)

    if plant_id:
        query = query.join(Line).join(Loop).join(
            Zone).filter(Zone.plant_id == plant_id)

    if zone_id:
        query = query.join(Line).join(Loop).filter(Loop.zone_id == zone_id)

    if loop_id:
        query = query.join(Line).filter(Line.loop_id == loop_id)

    if line_id:
        query = query.filter(Production.line_id == line_id)

    if date_value:
        query = query.join(Shift).filter(Shift.date == date_value)

    if day_night:
        query = query.join(Shift).filter(Shift.day_night == day_night)

    if planner_id:
        query = query.filter(Production.planner_id == planner_id)

    if team_leader_id:
        query = query.filter(Production.team_leader_id == team_leader_id)

    if shift_id:
        query = query.filter(Production.shift_id == shift_id)

    if hour:
        query = query.filter(Production.hour == hour)

    productions = query.all()
    return productions


@router.get("/{production_id}", response_model=ProductionResponse)
async def get_production(production_id: int, db: Session = Depends(get_db)):
    production = db.query(Production).filter(
        Production.id == production_id).first()
    if not production:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Production not found"
        )
    return production
