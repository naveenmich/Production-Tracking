from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from database.models import Production, Line, Shift, Planner
from database.service import get_db
from schemas.plan import PlanCreate, PlanResponse
from typing import List

router = APIRouter()


@router.post("", response_model=PlanResponse, status_code=status.HTTP_201_CREATED)
async def create_plan(plan: PlanCreate, db: Session = Depends(get_db)):
    # Check if line exists
    line = db.query(Line).filter(Line.id == plan.line_id).first()
    if not line:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Line not found"
        )

    # Check if shift exists
    shift = db.query(Shift).filter(Shift.id == plan.shift_id).first()
    if not shift:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Shift not found"
        )

    # Check if planner exists
    planner = db.query(Planner).filter(
        Planner.user_id == plan.planner_id).first()
    if not planner:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Planner not found"
        )

    # Check if plan for this hour and shift already exists
    existing_plan = db.query(Production).filter(
        Production.shift_id == plan.shift_id,
        Production.line_id == plan.line_id,
        Production.hour == plan.hour
    ).first()
    if existing_plan:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Plan already exists for this shift and hour"
        )

    # Create new production plan
    new_plan = Production(
        plan=plan.plan,
        hour=plan.hour,
        line_id=plan.line_id,
        shift_id=plan.shift_id,
        planner_id=plan.planner_id,
        achievement=None,
        scraps=None,
        defects=None,
        flash=None
    )

    db.add(new_plan)
    db.commit()
    db.refresh(new_plan)

    return new_plan
