from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from database.models import Loss, LossReason, Production, Line, Loop, Zone, Plant
from database.service import get_db
from schemas.loss import LossCreate, LossResponse
from typing import List, Optional

router = APIRouter()


@router.post("", response_model=LossResponse, status_code=status.HTTP_201_CREATED)
async def create_loss(loss: LossCreate, db: Session = Depends(get_db)):
    # Check if loss reason exists
    loss_reason = db.query(LossReason).filter(
        LossReason.id == loss.loss_reason_id).first()
    if not loss_reason:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Loss reason not found"
        )

    # Check if production exists
    production = db.query(Production).filter(
        Production.id == loss.production_id).first()
    if not production:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Production not found"
        )

    # Create new loss
    new_loss = Loss(**loss.model_dump())
    db.add(new_loss)
    db.commit()
    db.refresh(new_loss)

    return new_loss


@router.get("", response_model=List[LossResponse])
async def get_losses(
    department: Optional[str] = None,
    loss_reason_id: Optional[str] = None,
    line_id: Optional[int] = None,
    loop_id: Optional[int] = None,
    zone_id: Optional[int] = None,
    plant_id: Optional[int] = None,
    db: Session = Depends(get_db)
):
    query = db.query(Loss)

    if department:
        query = query.join(LossReason).filter(
            LossReason.department == department)

    if loss_reason_id:
        query = query.filter(Loss.loss_reason_id == loss_reason_id)

    if line_id:
        query = query.join(Production).filter(Production.line_id == line_id)

    if loop_id:
        query = query.join(Production).join(
            Line).filter(Line.loop_id == loop_id)

    if zone_id:
        query = query.join(Production).join(Line).join(
            Loop).filter(Loop.zone_id == zone_id)

    if plant_id:
        query = query.join(Production).join(Line).join(
            Loop).join(Zone).filter(Zone.plant_id == plant_id)

    losses = query.all()
    return losses


@router.get("/{loss_id}", response_model=LossResponse)
async def get_loss(loss_id: int, db: Session = Depends(get_db)):
    loss = db.query(Loss).filter(Loss.id == loss_id).first()
    if not loss:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Loss not found"
        )
    return loss
