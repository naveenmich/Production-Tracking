from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from database.models import PlantAdmin, Plant, User, UserRole
from database.service import get_db
from schemas.plant_admin import PlantAdminCreate, PlantAdminNewCreate, PlantAdminResponse
from typing import List, Optional

router = APIRouter()


@router.post("", response_model=PlantAdminResponse, status_code=status.HTTP_201_CREATED)
async def create_plant_admin(plant_admin: PlantAdminCreate, db: Session = Depends(get_db)):
    # Check if user exists
    user = db.query(User).filter(User.sap_id == plant_admin.sap_id).first()
    if not user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="User not found"
        )

    # Check if plant exists
    plant = db.query(Plant).filter(Plant.id == plant_admin.plant_id).first()
    if not plant:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Plant not found"
        )

    # Check if plant admin already exists
    existing_plant_admin = db.query(PlantAdmin).filter(
        PlantAdmin.user_id == plant_admin.sap_id
    ).first()
    if existing_plant_admin:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Plant admin already exists for this user"
        )

    # Create new plant admin
    new_plant_admin = PlantAdmin(
        user_id=plant_admin.sap_id,
        plant_id=plant_admin.plant_id
    )

    # Update user role to PLANT_ADMIN
    user.role = UserRole.PLANT_ADMIN

    db.add(new_plant_admin)
    db.commit()
    db.refresh(new_plant_admin)

    return new_plant_admin


@router.post("/new", response_model=PlantAdminResponse, status_code=status.HTTP_201_CREATED)
async def create_new_plant_admin(plant_admin: PlantAdminNewCreate, db: Session = Depends(get_db)):
    # Check if user already exists
    existing_user = db.query(User).filter(
        User.sap_id == plant_admin.sap_id).first()
    if existing_user:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="User with this SAP ID already exists"
        )

    # Check if plant exists
    plant = db.query(Plant).filter(Plant.id == plant_admin.plant_id).first()
    if not plant:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Plant not found"
        )

    # Create new user with SAP ID as password
    new_user = User(
        sap_id=plant_admin.sap_id,
        name=plant_admin.name,
        role=UserRole.PLANT_ADMIN,
        password=plant_admin.sap_id  # In production, this should be hashed
    )
    db.add(new_user)

    # Create new plant admin
    new_plant_admin = PlantAdmin(
        user_id=plant_admin.sap_id,
        plant_id=plant_admin.plant_id
    )
    db.add(new_plant_admin)

    db.commit()
    db.refresh(new_plant_admin)

    return new_plant_admin


@router.get("", response_model=List[PlantAdminResponse])
async def get_plant_admins(
    plant_id: Optional[int] = None,
    user_id: Optional[str] = None,
    db: Session = Depends(get_db)
):
    query = db.query(PlantAdmin)

    if plant_id:
        query = query.filter(PlantAdmin.plant_id == plant_id)

    if user_id:
        query = query.filter(PlantAdmin.user_id == user_id)

    plant_admins = query.all()
    return plant_admins


@router.get("/{user_id}", response_model=PlantAdminResponse)
async def get_plant_admin(user_id: str, db: Session = Depends(get_db)):
    plant_admin = db.query(PlantAdmin).filter(
        PlantAdmin.user_id == user_id).first()
    if not plant_admin:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Plant admin not found"
        )
    return plant_admin
