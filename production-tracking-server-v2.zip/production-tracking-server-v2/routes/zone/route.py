from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from database.models import Zone, Plant
from database.service import get_db
from schemas.zone import ZoneCreate, ZoneResponse
from typing import List

router = APIRouter()


@router.post("", response_model=ZoneResponse, status_code=status.HTTP_201_CREATED)
async def create_zone(zone: ZoneCreate, db: Session = Depends(get_db)):
    # Check if plant exists
    plant = db.query(Plant).filter(Plant.id == zone.plant_id).first()
    if not plant:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Plant not found"
        )

    # Create new zone
    new_zone = Zone(**zone.model_dump())
    db.add(new_zone)
    db.commit()
    db.refresh(new_zone)

    return new_zone


@router.get("", response_model=List[ZoneResponse])
async def get_zones(plant_id: int = None, db: Session = Depends(get_db)):
    query = db.query(Zone)

    if plant_id:
        query = query.filter(Zone.plant_id == plant_id)

    zones = query.all()
    return zones


@router.get("/{zone_id}", response_model=ZoneResponse)
async def get_zone(zone_id: int, db: Session = Depends(get_db)):
    zone = db.query(Zone).filter(Zone.id == zone_id).first()
    if not zone:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Zone not found"
        )
    return zone
