# PHP DataClass Generator

A VS Code extension that automatically generates `fromArray()` and `fromArrayCollection()` methods for PHP immutable data classes based on constructor parameters.

## Features

- Analyzes PHP class constructors to extract parameter information
- Generates type-safe conversion methods from array data
- Handles primitive types, objects, and collections
- Supports nullable types and default values
- Includes validation for required fields
- Maintains proper DocBlock documentation


## Requirements

- Visual Studio Code 1.60.0 or higher
- PHP files with classes that extend a base `DataClass`

## Installation

1. Install through VS Code Marketplace
2. Or download the `.vsix` file and install manually:
   ```
   code --install-extension php-dataclass-generator-0.1.0.vsix
   ```

## Usage

1. Open a PHP file containing a data class
2. Right-click anywhere in the editor
3. Select "PHP: Generate fromArray Methods" from the context menu
4. The extension will analyze the constructor and insert appropriate conversion methods

## Extension Settings

This extension contributes the following settings:

* `phpDataClassGenerator.includeValidation`: Enable/disable validation code generation (default: `true`)
* `phpDataClassGenerator.generateCollectionMethod`: Enable/disable generation of the collection method (default: `true`)

## Examples

Given a data class:

```php
final class User extends DataClass
{
    public function __construct(
        public readonly string $id,
        public readonly string $name,
        public readonly int $age,
        public readonly ?string $email = null,
        public readonly array $roles = []
    ) {
        $this->validateRequired();
    }
}
```

The extension will generate:

```php
/**
 * Creates a User instance from array data.
 *
 * @param array<string, mixed> $data
 * @return static
 */
public static function fromArray(array $data): static
{
    // Validate required fields
    foreach (['id', 'name', 'age'] as $requiredField) {
        if (!isset($data[$requiredField])) {
            throw new \InvalidArgumentException("Missing required field: {$requiredField}");
        }
    }
    
    return new self(
        id: $data['id'],
        name: $data['name'],
        age: (int)$data['age'],
        email: $data['email'] ?? null,
        roles: $data['roles'] ?? []
    );
}

/**
 * Creates a collection of User instances from array data.
 *
 * @param array<array<string, mixed>> $items
 * @return array<self>
 */
public static function fromArrayCollection(array $items): array
{
    return array_map(
        fn(array $item) => self::fromArray($item),
        $items
    );
}
```

## Known Issues

- Complex nested property structures may require manual adjustments
- Array type detection requires proper DocBlock comments
- Limited support for union types

## Release Notes

### 1.0.0

- Initial release with basic functionality
- Support for primitive types, nullable fields, and default values
- Generation of fromArray and fromArrayCollection methods

## Roadmap

- Improved support for complex types and generics
- Configuration options for customizing method generation
- Integration with PHP 8.1+ attributes

## License

This extension is licensed under the MIT License.