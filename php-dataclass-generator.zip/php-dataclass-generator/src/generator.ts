import * as vscode from 'vscode';
import { Parameter, parseConstructor, getClassName, isObjectType } from './parser';

function generateValidation(parameters: Parameter[]): string {
    const requiredParams = parameters
        .filter(p => !p.hasDefaultValue && !p.isNullable)
        .map(p => `'${p.name}'`);

    if (requiredParams.length === 0) {
        return '';
    }

    return `
        // Validate required fields
        foreach ([${requiredParams.join(', ')}] as $requiredField) {
            if (!isset($data[$requiredField])) {
                throw new \\InvalidArgumentException("Missing required field: {$requiredField}");
            }
        }
        
    `;
}

// Add object mapping function
function generateObjectMapping(param: Parameter): string {
    if (param.isNullable) {
        return `${param.name}: isset($data['${param.name}']) ? ${param.type}::fromArray($data['${param.name}']) : null`;
    } else {
        return `${param.name}: ${param.type}::fromArray($data['${param.name}'])`;
    }
}

// Add array mapping function
function generateArrayMapping(param: Parameter): string {
    if (!param.arrayItemType || !isObjectType(param.arrayItemType)) {
        return `${param.name}: $data['${param.name}'] ?? []`;
    }

    return `${param.name}: isset($data['${param.name}']) ? ${param.arrayItemType}::fromArrayCollection($data['${param.name}']) : []`;
}


export async function generateFromArrayMethod(
    document: vscode.TextDocument,
    editor: vscode.TextEditor
): Promise<void> {
    const code = document.getText();
    const parameters = parseConstructor(code);
    const className = getClassName(code);

    const insertPosition = findInsertPosition(document);
    const generatedCode = generateCode(parameters, className);

    await editor.edit(editBuilder => {
        editBuilder.insert(insertPosition, generatedCode);
    });
}

function findInsertPosition(document: vscode.TextDocument): vscode.Position {
    // Find position before last closing brace
    const text = document.getText();
    const lastBraceIndex = text.lastIndexOf('}');
    return document.positionAt(lastBraceIndex);
}
// Update the generateCode function
function generateCode(parameters: Parameter[], className: string): string {
    const config = vscode.workspace.getConfiguration('phpDataClassGenerator');
    const includeValidation = config.get('includeValidation', true);
    const generateCollectionMethod = config.get('generateCollectionMethod', true);

    const validation = includeValidation ? generateValidation(parameters) : '';

    const parameterMappings = parameters.map(param => {
        let mapping = '';

        // Check for object type
        if (isObjectType(param.type)) {
            mapping = generateObjectMapping(param);
        }
        // Check for array type with object items
        else if (param.type === 'array' && param.arrayItemType) {
            mapping = generateArrayMapping(param);
        }
        // Handle primitive types
        else if (param.hasDefaultValue && param.isNullable) {
            mapping = `${param.name}: $data['${param.name}'] ?? null`;
        } else if (param.hasDefaultValue) {
            mapping = `${param.name}: $data['${param.name}'] ?? []`;
        } else if (param.type === 'int' || param.type === 'float') {
            mapping = `${param.name}: (${param.type})$data['${param.name}']`;
        } else if (param.type === 'bool') {
            mapping = `${param.name}: (bool)$data['${param.name}']`;
        } else if (param.isNullable) {
            mapping = `${param.name}: $data['${param.name}'] ?? null`;
        } else {
            mapping = `${param.name}: $data['${param.name}']`;
        }

        return mapping;
    }).join(",\n        ");

    let code = `
    /**
     * Creates a ${className} instance from array data.
     *
     * @param array<string, mixed> $data
     * @return static
     */
    public static function fromArray(array $data): static
    {${validation}
        return new self(
        ${parameterMappings}
        );
    }`;

    if (generateCollectionMethod) {
        code += `

    /**
     * Creates a collection of ${className} instances from array data.
     *
     * @param array<array<string, mixed>> $items
     * @return array<self>
     */
    public static function fromArrayCollection(array $items): array
    {
        return array_map(
            fn(array $item) => self::fromArray($item),
            $items
        );
    }`;
    }

    return code;
}