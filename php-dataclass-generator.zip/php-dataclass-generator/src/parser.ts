// Add to the Parameter interface
export interface Parameter {
    name: string;
    type: string;
    isNullable: boolean;
    hasDefaultValue: boolean;
    arrayItemType?: string; // Add this line
}
export function parseConstructor(code: string): Parameter[] {
    const constructorRegex = /public\s+function\s+__construct\s*\(([\s\S]*?)\)/;
    const match = constructorRegex.exec(code);

    if (!match || !match[1]) {
        throw new Error('Constructor not found or has no parameters');
    }

    const parameterString = match[1];
    return extractParameters(parameterString, code);
}

function extractParameters(parameterString: string, fullCode: string): Parameter[] {
    const parameterRegex = /(?:public\s+readonly\s+)?([?\w\\]+)\s+\$(\w+)(?:\s*=\s*([^,)]+))?/g;
    const parameters: Parameter[] = [];

    let match;
    while ((match = parameterRegex.exec(parameterString)) !== null) {
        const typeString = match[1];
        const name = match[2];
        const defaultValue = match[3];

        let param = {
            name,
            type: typeString.replace('?', ''),
            isNullable: typeString.startsWith('?'),
            hasDefaultValue: defaultValue !== undefined
        };

        // Extract array type hint information
        if (param.type === 'array') {
            param = extractArrayTypeHint(fullCode, param);
        }

        parameters.push(param);
    }

    return parameters;
}

function extractArrayTypeHint(code: string, param: Parameter): Parameter {
    // Look for @param annotation with array type information
    const docRegex = new RegExp(`@param\\s+array<(\\w+)>\\s+\\$${param.name}`);
    const match = docRegex.exec(code);

    if (match && match[1]) {
        param.arrayItemType = match[1];
    }

    return param;
}

export function getClassName(code: string): string {
    const classRegex = /class\s+(\w+)/;
    const match = classRegex.exec(code);

    if (!match || !match[1]) {
        throw new Error('Class name not found');
    }

    return match[1];
}

export function isObjectType(type: string): boolean {
    // Check if type isn't a primitive type
    return !['string', 'int', 'float', 'bool', 'array', 'mixed'].includes(type.toLowerCase());
}