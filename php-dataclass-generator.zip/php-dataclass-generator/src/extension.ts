import * as vscode from 'vscode';
import { generateFromArrayMethod } from './generator';

export function activate(context: vscode.ExtensionContext) {
	const disposable = vscode.commands.registerCommand(
		'php-dataclass-generator.generateFromArray',
		generateFromArrayHandler
	);

	context.subscriptions.push(disposable);
}
async function generateFromArrayHandler() {
	const editor = vscode.window.activeTextEditor;
	if (!editor) {
		vscode.window.showErrorMessage('No active editor found');
		return;
	}

	const document = editor.document;
	if (document.languageId !== 'php') {
		vscode.window.showErrorMessage('Active file is not a PHP file');
		return;
	}

	try {
		// Check if file contains a class that extends DataClass
		const text = document.getText();
		if (!text.includes('extends DataClass')) {
			vscode.window.showWarningMessage('This file does not appear to contain a DataClass. Continue anyway?', 'Yes', 'No')
				.then(async choice => {
					if (choice === 'Yes') {
						await generateFromArrayMethod(document, editor);
						vscode.window.showInformationMessage('fromArray methods generated successfully');
					}
				});
			return;
		}

		await generateFromArrayMethod(document, editor);
		vscode.window.showInformationMessage('fromArray methods generated successfully');
	} catch (error) {
		if (error instanceof Error) {
			vscode.window.showErrorMessage(`Error generating methods: ${error.message}`);
		} else {
			vscode.window.showErrorMessage('Error generating methods');
		}
	}
}